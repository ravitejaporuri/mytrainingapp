#!/home/ipautomata/perl5/perlbrew/perls/perl-5.18.0/bin/perl

use warnings;
use strict;
use File::Basename;
use Getopt::Long;
use Data::Dumper;
use DBI;

sub usage($);
my $name = basename $0;

my $myStart = $ARGV[0];

usage(1) unless defined $myStart;

GetOptions(     "name=n"        =>\$myStart);
sub usage($)
{
        my $exitval = shift;
        print <<"USAGE";
        Usage: 
        ./$name [serviceID]

        Example
        -------
        ./$name 218195
        
USAGE
        exit $exitval;
}


my $dsn = "dbi:mysql:host=ipdb-s;database=IPradar;port=3306;mysql_compression=1";
my $user = 'readonly';
my $passwd = $opts{'passwd'};
my %dbparams = ( RaiseError => 1, PrintError => 1 );

my $dbh = DBI->connect($dsn, $user, $passwd, { %dbparams });
        die $DBI::errstr unless $dbh;

$dbh->{'mysql_enable_utf8'} = 1;
$dbh->do('SET NAMES utf8');

my $query = <<HERE;

select distinct cl.ClientClientname as 'client',
	ex.execution_id,
	au.automaton_id,
	au.name as 'automaton',
	st.name as 'state'
from IPautomata.execution ex
	inner join IPautomata.execution_pointer xp on ex.execution_id = xp.execution_id
	inner join IPautomata.state_execution sx on ex.execution_id = sx.execution_id
	inner join IPautomata.state st on sx.state_id = st.state_id
	inner join IPautomata.automaton au on st.automaton_id = au.automaton_id
	inner join auth.CLIENT cl on au.client_id = cl.ClientID
where xp.status = 'FAIL'
	and xp.current_state_id = sx.state_id
	and sx.return_code = '-729'
	and ex.created > '$myStart 09:00:00'
group by automaton_id


HERE

my $sth = $dbh->prepare($query);
$sth->execute or die $sth->errstr;
my $rows = $sth->rows;
while (my $data = $sth->fetchrow_arrayref()){
print "<TR><TD>$data->[0]</TD><TD><a href='https://ipcenter.ipsoft.com/IPautomata/executionDetails.htm?executionID=$data->[1]'>$data->[1]</a></TD><TD><a href='https://ipcenter.ipsoft.com/IPautomata/automatonDetails.htm?automatonID=$data->[2]'>$data->[2]</a></TD><TD>$data->[3]</TD><TD>$data->[4]</TD></TR>"
}
