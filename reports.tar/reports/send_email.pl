#!/usr/bin/perl

use MIME::Lite;
use Time::Local;
use Time::gmtime;
use POSIX 'strftime';
use Getopt::Long;

my ($to,$subject,$message,$file,$path);

sub usage() {
        print "$0 --to '<email addresses>' --subject '<subject>' --message '<mes sage>' --file '<filename> --path '<directory path>'\n";
        print "This is an example argument list to script:\n";
        exit 1;
}

my $result = GetOptions(\%options,
        'to=s' => \$to,
        'subject=s' => \$subject,
        'message=s' => \$message,
        'file=s' => \$file,
        'path=s' => \$path


);
# Check for required arguments
if (!$to||!$subject||!$message||!$file||!$path) {
        usage();
}


my $mmdd =`date +%m%d`;
chomp($mmdd);

my $message = MIME::Lite->new(
        From => "noreply\@ipctrprodna.ipctrna01.com",
        To   => "$to",
        Subject     => "$subject",
        Data        => "$message"
    );
    $message->attach(
        Type        => "text/plain",
        Path        => "$path/$file",
        Filename    => "$file",
        Encoding    => "base64",
        Disposition => "attachment",
    );
$message->send;

print "File Sent\n";

