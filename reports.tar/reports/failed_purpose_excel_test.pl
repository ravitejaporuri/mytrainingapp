#!/home/ipautomata/perl5/perlbrew/perls/perl-5.18.0/bin/perl
#
use strict;
use warnings;

use Getopt::Long;
use DBI;
use Data::Dumper;
use File::Basename;
#use Net::SMTP;
use MIME::Lite;
use Spreadsheet::WriteExcel;


sub usage($);
my $name = basename $0;

my %opts;

GetOptions (
        \%opts,
        'client=s',
        'email=s',
        'passwd=s',
	'days=s',
        'help'
);

usage(0) if exists $opts{'help'};
usage(1) unless exists $opts{'passwd'};
my $days = $opts{'days'};
$days = 1 unless $opts{'days'};
my $client = $opts{'client'};
$client = "" unless $opts{'client'};

my @headings = ("ClientClientname", "name", "Intended", "Executed", "created", "status", "Name", "URL");

my ($sth, $rv, $sth2);

my $dsn = "dbi:mysql:host=ipdb-s;database=IPradar;port=3306;mysql_compression=1";
my $user = 'readonly';
my $passwd = $opts{'passwd'};
my %dbparams = ( RaiseError => 1, PrintError => 1 );

my $dbh = DBI->connect($dsn, $user, $passwd, { %dbparams });
        die $DBI::errstr unless $dbh;

$dbh->{'mysql_enable_utf8'} = 1;
$dbh->do('SET NAMES utf8');

my $file='/tmp/purpose_change_report.xls';
my $workbook = Spreadsheet::WriteExcel->new($file);
my $worksheet = $workbook->add_worksheet('Automata Failures');

my $query_string = qq|SELECT 
    aucl.ClientClientname,
    a.name,
    a.automaton_id,
    au.Email,
    CONCAT(au.Firstname,' ',au.LastName) Name,
    e.execution_id,
	a.purpose as Intended,
    e.purpose as Executed,
    e.created,
    e.status,
    CONCAT("https://ipctrprodna.ipctrna01.com/IPautomata/executionDetails.htm?executionID=", e.execution_id) URL
FROM
    IPautomata.automaton a
    INNER JOIN auth.LOGIN au ON
        (au.LoginID=a.creator_id)
    INNER JOIN auth.CLIENT aucl ON
        (aucl.ClientID=a.client_id)
    INNER JOIN IPautomata.execution e ON
         (e.success=1 AND
          e.automaton_id=a.automaton_id AND
          e.purpose = 'DIAGNOSIS')
WHERE
    a.purpose='REMEDIATION' AND
    e.created > DATE_SUB(CURDATE(), INTERVAL $days DAY) AND 
    e.created < DATE_SUB(CURDATE(), INTERVAL 0 DAY) AND
    a.approval_status = "APPROVED" AND
    aucl.ClientClientname LIKE "%$client%"|;


$sth = $dbh->prepare($query_string);
$sth->execute or die $sth->errstr;
my $data = $sth->fetchall_hashref('execution_id');
my $row = 0;
my $col = 0;

#print out the column headings
for (my $x=0; $x < 13;$x++){
  $worksheet->write($row,$col,$headings[$x]);
  $col++;
}
$row++;
$col = 0;

#print Dumper($data);
#exit;
#populate the first worksheet

#foreach (keys %$data) {
foreach my $temp (sort keys %$data) {
#  my $temp = $_;
	foreach (@headings){
	  if (defined $data->{$temp}->{$_}){
	    unless ($_ eq "URL"){
	      $worksheet->write_string($row,$col, "$data->{$temp}->{$_}");
	      $col++;
	    } else {
 	      $worksheet->write($row,$col, "$data->{$temp}->{$_}");
              $col++;
 	    }
	  } else {
	    $worksheet->write($row,$col,"N/A");
	    $col++;
	 } 
	}
  $row++;
  $col = 0;
}

$workbook->close();
if ( exists $opts{'email'}){
  my $message = MIME::Lite->new(
        From => "noreply\@ipcenter.ipsoft.com",
       To   => $opts{'email'},
        Subject     => "IPautomata Purpose change report for the past 24 hours",
        Data        => 'Hello,

  The automata PURPOSE change report is attached.

Thank You,
IPsoft IPautomata'
    );
  $message->send;
  unlink $file || warn "Can't delete $file: $!\n";
}
else
{
  print "\n\tYour report is ready: $file\n\n";
}

sub usage($) {
        my $exitval = shift;

        print << "USAGE";

        Usage: $name [OPTIONS]

        Options
        -------
        --client        The client you wish to report the report for. (Client Code) DEFAULT: ALL
        --email         Where to send the report. DEFAULT: Print File Location to Screen
        --passwd        The DB access password
        --days          for how many days in the past you want this report

        --email If an email address is not supplied, the filename will be printed to screen for you to scp someplace.
	If you use the email option, the file will sent and then deleted from the produtil machine.
	--client If not supplied will run for ALL clients, else will run on a specific client.
	--days number of last X days to include in report.

        Example:

        $name --client IGA --start 2012-08-01 --end 2012-08-31 --email evayserberg\@ipsoft.com --passwd 1234567 --days 7


USAGE

        exit $exitval;
}

