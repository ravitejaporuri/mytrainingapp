#!/home/ipautomata/perl5/perlbrew/perls/perl-5.18.0/bin/perl
#
#
#       Devendra K Gupta
#       <devendra.gupta@in.ibm.com>
#
#
use Excel::Writer::XLSX;
use Getopt::Long;
use File::Basename;
use DBI;
use Data::Dumper; # For debugging purposes
use Date::Range;
use Date::Simple;
use MIME::Lite;
use Carp;
use strict;
use Env qw/USER/;


sub usage($);
sub generateQuery(%);

my $name = basename $0;

my %opts;

GetOptions (
        \%opts,
        'client=s',
        'start=s',
        'end=s',
        'email=s',
        'passwd=s',
        'port=i',
        'help'
);

usage(0) if exists $opts{'help'};
#usage(1) unless exists $opts{'client'};
usage(1) unless exists $opts{'start'};
usage(1) unless exists $opts{'end'};
usage(1) unless exists $opts{'passwd'};
#usage(1) unless exists $opts{'port'};
usage(1) unless exists $opts{'email'};



my $start_date = Date::Simple->new($opts{'start'});
my $end_date = Date::Simple->new($opts{'end'});

if ( $start_date > $end_date )
{
        croak "ERROR: The start date ($start_date) is later than the end date ($end_date)";
}

croak "\nInvalid Date: $opts{'start'}\n" unless $start_date;
croak "\nInvalid Date: $opts{'end'}\n" unless $end_date;

my $date_range = Date::Range->new($start_date, $end_date);

my $file = "/tmp/csi_monthly_report.$opts{'client'}.$opts{'start'}-$opts{'end'}.$$.xlsx";
my $filename = basename $file;

my $workbook = Excel::Writer::XLSX->new($file);
my $worksheet = $workbook->add_worksheet($opts{'client'});
my $author = `grep $USER /etc/passwd | cut -f 5 -d :`;

$workbook->set_properties(
        title           =>      "CSI Monthly Report: $opts{'client'}",
        author  =>      $author,
        comments        =>      "Created with Perl/Excel::Writer::XLSX"

);

my $dsn = "dbi:mysql:host=pvdb02;database=IPradar;port=3306;mysql_compression=1";
my $user = 'readonly';
my $passwd = $opts{'passwd'};
my %dbparams = ( RaiseError => 1, PrintError => 1 );

my $dbh = DBI->connect($dsn, $user, $passwd, { %dbparams });
        die $DBI::errstr unless $dbh;

$dbh->{'mysql_enable_utf8'} = 1;
$dbh->do('SET NAMES utf8');


#my %parameters = ( client => 'MS-WISE', date => '2012-08-30');

my @correlated;
my @filtered;
my @resolve;
my @escalate;
my @manual;
my @create;

my $headers = (); # Set up our array reference

my $row = 0;
my $col = 0;


foreach my $date ($date_range->dates)
{
        # Set up our counters
        my $manual = 0;
        my $escalate = 0;
        my $resolve = 0;
        my $filtered = 0;
        my $correlated = 0;
        my $total = 0;
	my $master_id = 'NULL';

        # Set Classifcation
        my $classification = 'NULL';

        my %parameters = ( client => $opts{'client'}, date => $date );


        my $sql = generateQuery(\%parameters);

        my $sth = $dbh->prepare(${$sql}) or die $dbh->errstr;
        $sth->execute();
        $headers = $sth->{'NAME'}; # Get Column Headings

        # Our bind variables
         my ($radar_id, $execution_id, $create_date, $finish_date, $execution_time_in_sec,$actual_automata_purpose,$execution_purpose,$closure_code,$description,$hostname,$service,$owner,$automaton,$component_name,$cmdb_details,$fcode,$failure_reason,$return_code,$stdout,$stderr,$command_description,$status,$queue,$ipim_id,$ebond,$clientname,$affected_host,$component_output,$Situation);
		
		$sth->bind_col(1, \$radar_id);
		$sth->bind_col(2, \$execution_id);
        $sth->bind_col(3, \$create_date);
        $sth->bind_col(4, \$finish_date);
        $sth->bind_col(5, \$execution_time_in_sec);
        $sth->bind_col(6, \$actual_automata_purpose);
		$sth->bind_col(7, \$execution_purpose);
		$sth->bind_col(8, \$closure_code);
		$sth->bind_col(9, \$description);
        $sth->bind_col(10, \$hostname);
        $sth->bind_col(11, \$service);
        $sth->bind_col(12, \$owner);
        $sth->bind_col(13, \$automaton);
	$sth->bind_col(14, \$component_name);       
        $sth->bind_col(15, \$cmdb_details);
		$sth->bind_col(16, \$fcode);
		$sth->bind_col(17, \$failure_reason);
		$sth->bind_col(18, \$return_code);
	$sth->bind_col(19, \$stdout);
	$sth->bind_col(20, \$stderr);
	$sth->bind_col(21, \$command_description);
        $sth->bind_col(22, \$status);
        $sth->bind_col(23, \$queue);
        $sth->bind_col(24, \$ipim_id);
        $sth->bind_col(25, \$ebond);
        $sth->bind_col(26, \$clientname);
	$sth->bind_col(27, \$affected_host);
	$sth->bind_col(28, \$component_output);
	$sth->bind_col(29, \$Situation);
        
		
      while ($sth->fetch)
        {
                if ($master_id ne 'NULL')
                {
                        $classification = 'Event Correlated';
                        $correlated++;
                }else
                {
                        if ( $execution_purpose eq 'REMEDIATION' and $status ne 'AUTO_ABORTED')
                        {
                                $classification = 'REMEDIATION';
                                $resolve++;
                        }elsif ( $execution_purpose eq 'DIAGNOSIS' and $status ne 'AUTO_ABORTED' and $automaton !~ /Escalation Handler/)
                        {
                                $classification = 'DIAGNOSIS';
                                $escalate++;
                        }else
                        {
                                $classification = 'ESCALATE';
                                $filtered++;
                        }
                }

                $total++;
 
                # Write to excel / start @ row 1 - so we can back track and add the headers.
                $col = 0;
                $row++;

                $worksheet->write($row, $col, $radar_id);
                $col++;
                $worksheet->write($row, $col, $execution_id);
                $col++;
                $worksheet->write($row, $col, $create_date);
                $col++;
		$worksheet->write($row, $col, $finish_date);
                $col++;
                $worksheet->write($row, $col, $execution_time_in_sec);
                $col++;
                $worksheet->write($row, $col, $actual_automata_purpose);
                $col++;
		$worksheet->write($row, $col, $execution_purpose);
                $col++;
		$worksheet->write($row, $col, $closure_code);
                $col++;
                $worksheet->write($row, $col, $description);
                $col++;
                $worksheet->write($row, $col, $hostname);
                $col++;
                $worksheet->write($row, $col, $service);
                $col++;
                $worksheet->write($row, $col, $owner);
                $col++;
                $worksheet->write($row, $col, $automaton);
		$col++;
		$worksheet->write($row, $col, $component_name);
		$col++;
		$worksheet->write($row, $col, $cmdb_details);
                $col++;
                $worksheet->write($row, $col, $fcode);
                $col++;
		$worksheet->write($row, $col, $failure_reason);
                $col++;
		$worksheet->write($row, $col, $return_code);
                $col++;
		$worksheet->write($row, $col, $stdout);
                $col++;
		$worksheet->write($row, $col, $stderr);
                $col++;	
		$worksheet->write($row, $col, $command_description);
                $col++;	
                $worksheet->write($row, $col, $status);
                $col++;
                $worksheet->write($row, $col, $queue);
                $col++;
                $worksheet->write($row, $col, $ipim_id);
                $col++;
                $worksheet->write($row, $col, $ebond);
                $col++;
                $worksheet->write($row, $col, $clientname);
                $col++;
		$worksheet->write($row, $col, $affected_host);
                $col++;
                $worksheet->write($row, $col, $component_output);
                $col++;
                $worksheet->write($row, $col, $Situation);
               
        } # End Fetch
        
		# Compile Data for Graph
        push @create, $create_date;
        push @resolve, $resolve;
        push @escalate, $escalate;
        push @filtered, $filtered;
        push @correlated, $correlated;

        $sth->finish();
}

$dbh->disconnect();

my @row = @{$headers};;


# Headers Format
my $format = $workbook->add_format();
$format->set_bold();
$format->set_align('center');

# Add Headers to Sheet 1
$col = 0;

foreach (@row) {
        $worksheet->write(0, $col, $_, $format);
        $col++;
}
$workbook->close();

if ( exists $opts{'email'})
{
        system("gzip $file");
        my $msg = MIME::Lite->new (
                From    =>      'Raw Report <rawreport@ipctrtok01.com>',
                To              =>      $opts{'email'},
                Subject =>      "IPsoft Automaton Report $opts{'client'} - $opts{'start'} - $opts{'end'}",
                Type    =>      'multipart/mixed'
        ) or die 'Error creating multipart container.';

        $msg->attach (
                Type    =>      'TEXT',
                Data    =>      'Please see attached.',
        ) or die 'Error adding text message.';

        $msg->attach(
                Type    =>      'application/vnd.ms-excel',
                Path    =>      $file.'.gz',
                Filename        =>      $filename.'.gz',
                Disposition     =>      'attachment'
        ) or die "Error adding $filename.";

        MIME::Lite->send('smtp', 'localhost', Timeout => 60 );
        eval { $msg->send; };
        die $@ if $@;

        print "\n\tYour report is sent to: $opts{'email'}\n\n";
        #unlink $file.'.gz' || warn "Can't delete $file: $!\n";
}
else
{
        print "\n\tYour report is ready: $file\n\n";
}


#### Sub Routines ####

sub generateQuery(%) {
        my $parameters = shift;

        my $client = '';
        if ($parameters->{'client'} ne ''){
                $client='ac.ClientClientName LIKE ' . $dbh->quote($parameters->{'client'}) . ' and ';
        }

        my $query = <<"QUERY";
		
		select DISTINCT(tr.ticket_id) as Radar_id, ifnull(ie.execution_id, "NULL") as Execution_id, ie.created as create_date, ie.finished as finish_date, TIMESTAMPDIFF(SECOND,ie.created,ie.finished) as Execution_time_in_Sec, ia.purpose as Actual_Automata_purpose, ifnull(ie.purpose,"NULL") as Execution_Purpose,ifnull(cfo.value,"NULL") AS closure_code, tr.description as description, ipmtm.host as Hostname, ipmtm.service as Service, CASE WHEN al.username like 'ipautomata' OR al.username like 'NULL' THEN al.username ELSE 'NULL' END as username, ifnull(ia.name, "NULL") as automaton, CASE WHEN (auto.name LIKE '%:R:C:%' OR auto.name LIKE '%:D:C:%') AND auto.approval_status='APPROVED' THEN auto.name ELSE "NO Automation" END as component_name, ifnull(se.stdout, "NULL") as cmdb_details, ifnull(fcode.name, "NULL") as fcode, ifnull(se1.failure_reason, "NULL") as failure_reason, ifnull(se1.return_code, "NULL") as return_code, ifnull(se1.stdout,"NULL") as stdout,ifnull(se1.stderr, "NULL") as stderr,ifnull(se1.command_description, "NULL") as command_description ,ifnull(ie.status,"NULL") as status, ifnull(qs.Name,"NULL") as queue_name, ifnull(im.ipim_id,"NULL") as ipim_id, et.externalTicketID as EBondTicket,ac.ClientClientName as Client, ifnull(ev.value,"NULL") as  affected_host,ifnull(se0.stdout,"NULL") as component_output, IF(locate('AlertKey:',group_concat(ta.value order by ta.name SEPARATOR ''))>0,trim(left(SUBSTR(group_concat(ta.value order by ta.name SEPARATOR ''),locate('AlertKey:',group_concat(ta.value order by ta.name SEPARATOR ''))+9),locate('<',SUBSTR(group_concat(ta.value order by ta.name SEPARATOR ''),locate('AlertKey:',group_concat(ta.value order by ta.name SEPARATOR ''))+9))-1)),'NO ALERT KEY') AS Situation from (select * from IPradar.tickets_resolved itr where itr.create_date like "$parameters->{'date'}%" UNION select * from IPradar.tickets it where it.create_date like "$parameters->{'date'}%") as tr 
						inner join auth.CLIENT ac on (tr.client_id = ac.ClientID)
                                                left outer join auth.LOGIN al on (al.LoginID = tr.owner_id)
                                                left outer join IPautomata.execution ie on ((ie.creator_id IS NULL OR ie.creator_id=2580) AND ie.ticket_id = tr.ticket_id)
                                                left outer join IPautomata.state_execution se on (se.execution_id = ie.execution_id AND (se.command_description LIKE '%component_output%' AND (se.stdout LIKE '%CMDB Checks failed%' OR se.stdout LIKE '%CMDB: CI%')))
                                                left outer join IPautomata.state_execution se0 on (se0.execution_id = ie.execution_id AND se0.command_description LIKE '%final_output%')						left outer join IPautomata.execution_variable ev on (ev.execution_id = ie.execution_id AND ev.name= 'affected_host' AND ev.state_scope_id IS NULL)
                                                left outer join IPautomata.automaton ia on (ie.automaton_id = ia.automaton_id)
                                                left outer join IPradar.custom_field cf ON (cf.ticket_id = tr.ticket_id AND cf.custom_field_definition_id=2)
                                                left outer join IPradar.select_custom_field scf ON (scf.custom_field_id = cf.custom_field_id)
                                                left outer join IPradar.custom_field_option cfo ON (scf.custom_field_option_id NOT IN (1,2,7) AND cfo.custom_field_option_id = scf.custom_field_option_id)
                                                left outer join IPautomata.execution ipaut ON (ipaut.ticket_id = tr.ticket_id)
                                                left outer join IPautomata.execution_pointer iep on (iep.execution_id = ie.execution_id)
                                                left outer join IPautomata.state ist on ( ist.state_id = iep.current_state_id )
						left join IPautomata.state fcode on ((select state_id from IPautomata.state_execution where execution_id=ie.execution_id order by state_execution_id desc limit 1)= fcode.state_id)
						left join IPautomata.state_execution se1 ON (se1.execution_id=ie.execution_id AND fcode.state_id=se1.state_id)
                                                left outer join IPautomata.execution_pointer xpoint on ( ist.state_id = (CASE WHEN ia.name like '%Escalation%' OR ia.name like '%Blacklist%' THEN xpoint.current_state_id ELSE (select xpt.current_state_id from IPautomata.execution_pointer xpt where ie.execution_id = xpt.execution_id ORDER By xpt.execution_pointer_id DESC LIMIT 1,1) END ))
                                                left outer join IPautomata.automaton auto ON ( ist.automaton_id = auto.automaton_id )
						left outer join IPradar.ipim_ticket_mapping im on (tr.ticket_id = im.ticket_id)
                                                left outer join IPim.Tickets ts on ( im.ipim_id = ts.id) left outer join IPim.Queues qs on (ts.Queue = qs.id)
                                                left outer join IPradar.project_ticket_mapping pm on (pm.ticket_id = tr.ticket_id)
                                                left outer join IPradar.ipmon_ticket_mapping ipmtm on (tr.ticket_id = ipmtm.ticket_id)
                                                left outer join ebonding.ticket et on (tr.ticket_id = et.radarTicketID)
                                                left outer join IPradar.ticket_attribute ta on (ta.ticket_id=ie.ticket_id AND ta.value like '%AlertKey%')        


where
		tr.create_date like "$parameters->{'date'}%" AND ie.status IN ('COMPLETE','FAILED') AND pm.project_id is NULL AND
                $client
                tr.description not like "IPpm%" AND xpoint.execution_id = ie.execution_id AND tr.master_ticket_id is null
                group by ie.execution_id
QUERY

        #print Dumper($parameters)
        print "$query";

        return \$query;
}


sub usage($) {
        my $exitval = shift;

        print << "USAGE";
        Usage: $name [OPTIONS]

        Options
        -------
        --client        The client you wish to report the report for. (Client Code)
        --email         Where to send the report. DEFAULT: Print File Location to Screen
        --start         The start date for the report.
        --end           The end date for the report.
        --passwd        The DB access password

        All of the options are required accept --email. If an email address is not supplied, the filename
        will be printed to screen for you to scp someplace. If you use the email option, the file will sent and
        then deleted from the produtil machine.

        Example:

        $name --client IHG --start 2012-08-01 --end 2012-08-31 --email melissa.vandenbrink\@ipsoft.com --passwd 1234567


USAGE

        exit $exitval;
}
