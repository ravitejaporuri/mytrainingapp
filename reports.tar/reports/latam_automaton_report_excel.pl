#!/home/ipautomata/perl5/perlbrew/perls/perl-5.18.0/bin/perl
#
use strict;
use warnings;

use Getopt::Long;
use DBI;
use Data::Dumper;
use File::Basename;
#use Net::SMTP;
use MIME::Lite;
use Spreadsheet::WriteExcel;

my $name = basename $0;

my %opts;

GetOptions (
        \%opts,
        'client=s',
        'email=s',
        'passwd=s',
	'days=s',
        'help'
);

usage(0) if exists $opts{'help'};
usage(1) unless exists $opts{'passwd'};
my $days = $opts{'days'} || 1;

my $clients = $opts{'client'}
                  ? join(" OR ", map { "aucl.ClientClientname LIKE '$_'" } split(",", $opts{'client'}) )
                  : "1";

my @headings = ("ClientClientname", "name", "purpose", "created", "status", "failure_reason", "return_code", "fcode", "stdout", "stderr", "command_description", "Name", "URL");

my ($sth, $rv, $sth2);

my $dsn = "dbi:mysql:host=ipdb-s;database=IPradar;port=3306;mysql_compression=1";
my $user = 'readonly';
my $passwd = $opts{'passwd'};
my %dbparams = ( RaiseError => 1, PrintError => 1 );

my $dbh = DBI->connect($dsn, $user, $passwd, { %dbparams });
        die $DBI::errstr unless $dbh;

$dbh->{'mysql_enable_utf8'} = 1;
$dbh->do('SET NAMES utf8');

my $file='/tmp/automata_report_shared.xls';
my $workbook = Spreadsheet::WriteExcel->new($file);
my $worksheet = $workbook->add_worksheet('Automata Failures');

my $query_string = qq|SELECT 
    aucl.ClientClientname,
    a.name,
    a.automaton_id,
    au.Email,
    CONCAT(au.Firstname,' ',au.LastName) Name,
    e.execution_id,
    e.purpose,
    e.created,
    e.creator_id,
    fcode.name as fcode,
    e.status,
    se.command_description,
    se.return_code,
    se.stdout,
    se.stderr,
    se.failure_reason,
    se.status,
    CONCAT("https://ipctrprodna.ipctrna01.com/IPautomata/executionDetails.htm?executionID=", e.execution_id) URL 
FROM 
    IPautomata.automaton a
    INNER JOIN auth.LOGIN au ON 
        (au.LoginID=a.creator_id)
    INNER JOIN auth.CLIENT aucl ON 
        (aucl.ClientID=a.client_id)
    INNER JOIN IPautomata.execution e ON 
         (e.success=0 AND
          e.automaton_id=a.automaton_id AND
          e.purpose != 'ESCALATION' AND
          e.status='FAILED') 
    -- I do this to get the info on the last state that executed
    INNER JOIN IPautomata.state_execution se ON 
        (se.state_execution_id=
            (SELECT MAX(state_execution_id) 
             FROM IPautomata.state_execution
             WHERE execution_id=e.execution_id)
         )
    LEFT JOIN IPautomata.state fcode ON
       (fcode.state_id=
           (SELECT i_s.state_id
            FROM IPautomata.state_execution i_se
            INNER JOIN IPautomata.state i_s ON
               (i_s.name LIKE '%CODE%' AND 
                i_s.state_id=i_se.state_id)
            WHERE i_se.execution_id=e.execution_id 
            HAVING MAX(i_se.state_execution_id))
        )
WHERE 
    e.created > DATE_SUB(CURDATE(), INTERVAL $days DAY) AND 
    e.created < DATE_SUB(CURDATE(), INTERVAL 0 DAY) AND
    a.approval_status = "APPROVED" AND
    ($clients)|;

my $query2 = qq|
select cl.ClientClientName as "Client", sum(slr.automata_failed) as "Failures", (sum(slr.automata_resolved) + sum(automata_assisted)) as "Success", (sum(slr.automata_failed)/(sum(automata_failed)+sum(automata_resolved)+sum(automata_assisted))*100) as "Failure Pct"
from
    IPslr.ticket_summary slr
    inner join IPradar.tickets_resolved tr on (tr.ticket_id = slr.ticket_id)
    inner join auth.CLIENT cl on (tr.client_id = cl.ClientID)
where
    (slr.automata_failed = 1 or slr.automata_assisted = 1 or slr.automata_resolved = 1) and
    tr.resolve_date > DATE_SUB(CURDATE(), INTERVAL 1 DAY) 
group by cl.ClientClientName|;

$sth = $dbh->prepare($query_string);
$sth->execute or die $sth->errstr;
my $data = $sth->fetchall_hashref('execution_id');
my $row = 0;
my $col = 0;

#print out the column headings
for (my $x=0; $x < 13;$x++){
  $worksheet->write($row,$col,$headings[$x]);
  $col++;
}
$row++;
$col = 0;

print Dumper($data);
#exit;
#populate the first worksheet

#foreach (keys %$data) {
foreach my $temp (sort keys %$data) {
#  my $temp = $_;
	foreach (@headings){
	  if (defined $data->{$temp}->{$_}){
	    unless ($_ eq "URL"){
	      $worksheet->write_string($row,$col, "$data->{$temp}->{$_}");
	      $col++;
	    } else {
 	      $worksheet->write($row,$col, "$data->{$temp}->{$_}");
              $col++;
 	    }
	  } else {
	    $worksheet->write($row,$col,"N/A");
	    $col++;
	 } 
	}
  $row++;
  $col = 0;
}


=comment
#handle the failure percentage WS

my $pctws = $workbook->add_worksheet('Failure Percentages');
$sth2 = $dbh->prepare($query2);
$sth2->execute or die $sth2->errstr;
my $pctdata = $sth2->fetchall_hashref('Client');
my @failheadings = ("Client", "Failures", "Success", "Failure Pct");
$row = 0;
$col = 0;

#print out the column headings
for (my $x=0; $x < 5;$x++){
  $pctws->write($row,$col,$failheadings[$x]);
  $col++;
}
$row++;
$col = 0;

foreach (keys %$pctdata) {
  my $temp = $_;
  foreach (@failheadings){
      $pctws->write($row,$col,"$pctdata->{$temp}->{$_}");
      $col++;
  }
  $row++;
  $col = 0;
}
=cut
$workbook->close();
if ( exists $opts{'email'}){
  my $message = MIME::Lite->new(
        From => "noreply\@ipcenter.ipsoft.com",
       To   => $opts{'email'},
        Subject     => "IPautomata failure report for the past 24 hours",
        Data        => 'Hello,

  The automata report for IBM is attached.

Thank You,
IPsoft IPautomata'
    );

    $message->attach(
        Type        => 'application/vnd.ms-excel',
        Path        => $file,
        Filename    => 'automata_report_shared.xls',
        Encoding    => 'base64',
        Disposition => 'attachment',
    );
  $message->send;
  unlink $file || warn "Can't delete $file: $!\n";
}
else
{
  print "\n\tYour report is ready: $file\n\n";
}

sub usage {
        my $exitval = shift;

        print << "USAGE";

        Usage: $name [OPTIONS]

        Options
        -------
        --client        Optional: The client code(es) you wish to report the report for. DEFAULT is ALL CLIENTS
        --email         Where to send the report. DEFAULT: Print File Location to Screen
        --passwd        The DB access password
        --days          for how many days in the past you want this report

        --email If an email address is not supplied, the filename will be printed to screen for you to scp someplace.
        If you use the email option, the file will sent and then deleted from the produtil machine.
        --client If not supplied will run for ALL clients, else will run on a specific client.
        --days number of last X days to include in report.

        Example:

        $name --client IGA --start 2012-08-01 --end 2012-08-31 --email evayserberg\@ipsoft.com --passwd 1234567 --days 7

USAGE

        exit $exitval;
}

