$mypath = Read-host "Enter the path:"
$myarray = @()
$myarray = get-childitem -recurse | where-object {$_.PSIscontainer -eq $False}
$tem1 = New-item -type file temp1.csv -force
$tem2 = New-item -type file temp2.csv -force
$final = New-item -type file final.csv -force
$datey = (date).Adddays(-5)
foreach ($i in $myarray)
{
if($i.Extension -eq ".txt" -or $i.Extension -eq ".log")
{ 
 if($i.Length -lt 50MB) 
 { 
 if($i.CreationTime -gt $datey) 
  { 
$i | select {l="name";e={($_.name).tostring()}},{l="length";e={($_.length).tostring()}},{l="creationtime";e={($_.creationtime).tostring()}} | export-csv $tem
	if($final -eq $null) 
	{
	get-childitem $tem1 | foreach-object {Import-csv $_} | export-csv $final
	$final = import-csv final.csv
	}
	else {
	$tem2 = get-childitem $final
	get-childitem $tem1,$tem2 | foreach-object {Import-csv $_} | export-csv $final
        }
  }
 }
}

}