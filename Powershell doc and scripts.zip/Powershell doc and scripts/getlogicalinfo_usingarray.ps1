$serls = get-content Serverlist.txt
$myarr = @()
if ($serls -eq $null)
{
write-host "I cant do as there are no servers"
exit
}
else
{
foreach ($i in $serls)
{
# $val = test-path $i
# if($var -eq "True") {
$myarr += get-wmiobject -computername $i -class win32_logicaldisk | where-object {$_.Drivetype-eq 3 } | select systemname,DeviceID,@{label="size";exp={"{0:N2}" -f ($_.Size/1GB)}},@{label="FreeSpace";exp={"{0:N2}" -f ($_.FreeSpace/1GB)}}
$myarr | Export-csv myres.csv
}
}