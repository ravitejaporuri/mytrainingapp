# take a csv and add the content to the body of email instead of attachment

