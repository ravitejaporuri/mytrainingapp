# to install a patch after checking on the remote machine if the patch already exists and then install and wait for its completion. not complete. need to work in free time
# pseudo code

$date = get-date -f "dd-MM-yy-HH-mm"
$input = import-csv patchdetailsfile.csv
$succout = new-item -type file -name "installed-patches-and-servers-list.csv"
$failout = new-tem -type file -name "uninstalled-patches-and-servers-list.csv"

$i = 0
import-module "PSWindowsupdate"
$count = $input.count
do {
	if(\\$input[$i].server\admin) {
	$patch = $input[$i].patch

	get-childitem | foreach-object {$patch -eq ""}
	
	msiexec $patch

	$input.count++
   }
while($i -lt $input.count);
