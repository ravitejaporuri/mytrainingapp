$mypath = Read-host "Enter the path:"
$sum=0
$var = @()
$myarray = @()
$myarray = get-childitem *.log,*.txt | where-object {$_.PSIsContainer -eq $False}
$val = $myarray.count
for($i=0;$i -lt $val;$i++)
{
get-childitem $myarray[$i] | foreach-object {$sum += $_.Length}

$var += get-childitem $myarray[$i] | select Name,CreationTime,@{l="Path";e={(Convert-Path $_.PsPath)}},@{l="Length";e={($_.Length/1MB)}} 
}
Write-host $sum
$var | Export-csv output.csv