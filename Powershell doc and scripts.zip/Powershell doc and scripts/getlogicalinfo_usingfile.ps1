$serls = get-content Serverlist.txt
New-item -type file output.csv -force
New-item -type file temp.csv -force
$output = get-content output.csv
if ($serls -eq $null)
{
write-host "I cant do as there are no servers"
exit
}
else
{
foreach ($i in $serls)
{
get-wmiobject -computername $i -class win32_logicaldisk | where-object {$_.Drivetype -eq 3 } | select systemname,DeviceID,@{label="Size in GB";exp={($_.Size/1GB)}},@{label="FreeSpace";exp={($_.FreeSpace/1GB)}} | export-csv temp.csv
$tempy = get-content temp.csv
get-childitem $output,$tempy | foreach-object {$_} | export-csv output.csv
$output = get-content output.csv
}

}