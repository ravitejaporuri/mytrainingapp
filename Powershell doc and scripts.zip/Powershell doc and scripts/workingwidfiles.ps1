$mypath = Read-host "Enter the path:"
$var = @()
$myarray = @()
# $myarray = get-childitem *.log,*.txt | where-object {$_.PSIsContainer -eq $False}
$myarray = get-childitem -recurse | where-object {$_.PSIscontainer -eq $False}
$datey = (date).Adddays(-5)
foreach ($i in $myarray)
{
if($i.Extension -eq ".txt" -or $i.Extension -eq ".log")
{ 
 if($i.Length -lt 50MB) 
 { 
 if($i.CreationTime -gt $datey) 
  { 
	$var += $i | select name,length,creationtime
  }
 }
}

}
# Write-host $var
$var | Export-csv output.csv