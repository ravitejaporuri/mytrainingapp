#copy exe w.r.to csv file content on the servers.
# this program is to get exe files in a directory, take input file consisting server names and kbarticle names in csv files. When there is a match with kbarticle on the server, then it needs to install the file by checking if it already exists or not.
# Need to work


$hasharr = @{}
$var = @()
$ar = Get-Content .\mythings.txt
foreach ($i in $ar)
{
$var = $i.split("`t")
$hasharr.name += $var[0]
$hasharr.kbart += $var[1]
}
$myvar = @()
foreach ($i in $hasharr)
{
	$myvar += $i.name
}
write-host $myvar