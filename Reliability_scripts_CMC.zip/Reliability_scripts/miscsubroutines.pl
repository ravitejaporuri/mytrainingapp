#!/usr/bin/perl 

use lib $ENV{'PATH'}, "perl" ;

use Fcntl;
use Class::Struct;
use FindBin;
use File::Copy;
use File::Path;
use File::Which;

use lib "$FindBin::Bin";

require "PPRGlobals.pl";
require "PerfCompCommon.pl";

############### GLOBALS ###################
umask(000);		## override user umask so we all can have access

my $machineSpecificBinDir = "$FindBin::Bin/../bin.$OS-$OSRev-$machineType";

my $configDir = "/opt/XRXnps/configuration";
my $EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";

########## test ############
#
#######

my $ms_unittest = 0;

sub ts_set_ms_unittest() {
	$ms_unittest = 1;
} 

########## pwhich ##########
##  
##########

sub pwhich {
  ##TODO: look up how to catch exceptions, so that we can raise an exception
  ##here, and catch it in the tc_miscsubroutines and in all the other files
  local($exec_name) = @_;
  return which($exec_name);
}


########## findRubyExecutable ##########
##  
##########

sub findRubyExecutable {
	local($rubyExe) = @_;
	
	my $exe = pwhich($rubyExe);
		
	if (($exe eq "") or ($exe eq undef)) {
		$exe = "$CITD_HOME_BIN/$rubyExe";		
	}
		
	return($exe);
}

########## stripvalue ##########
## 
## strips leading and trailing white spaces from input.
## 
##########

sub stripvalue 
{
	local($thisvalue) = @_;
	$thisvalue =~ s/^\s+//; 			# no leading white 
	$thisvalue =~ s/\s+$//; 			# no trailing white 
	return($thisvalue);
}


########## ReadColorCapability ##########
##
## if it exists, Read <testname>.config and see if ColorCapability is specified
## If it is read it in.  Else have it set.
##
##########

sub ReadColorCapability {
	local($suitename, $testname, $path) = @_;
	
	my $colorcapfound = 0;
	my @colorcap = ();
	my $colors = "";
	
	if (-e "$path/$testname.config") {
		if (!(open(CONFIG, "<$path/$testname.config"))) {
			print("ReadColorCapability: Could not open, $path/$testname.config for reading\n");
			return();
		}		
		
		while (<CONFIG>) {
			chomp;
			my $nowvalue = stripvalue($_);
			if (/ColorCapability/) {
				($colors) = ($nowvalue =~ /^ColorCapability\s*(.+)\s*$/);
				($colors) =~s/=//g;
				($colors) =~s/://g;
				($colors) =~s/^\s+//; 			# no leading white 
				($colors) =~s/\s+$//; 			# no trailing white
				chomp($colors);
				@colorcap = split(/ /, $colors);
				last;
			}
		}
		
		close(CONFIG);
	}
	
	return(@colorcap);
}


########## CompareConfig ##########
##
## if it exists, Read Compare_Job.config and see if $item is specified
## If it is read it in.  Else have it set.  
## 
## This will change.  The Config will be <SuiteName>.config
## And the <testname>.config will override, but for now......
##
##########

sub ReadCompareConfig {
	local($path, $item) = @_;
	
	my $itemfound = 0;
	my $returnSting = "";
		
	if (-e "$path/Compare_Job.config") {
		if (!(open(CONFIG, "<$path/Compare_Job.config"))) {
			print("ReadCompareConfig: Could not open, $path/Compare_Job.config for reading\n");
			return();
		}
	}
	else {		
		my $compareConfig = findCompareConfig();
		
		if (!(open(CONFIG, "<$compareConfig"))) {
			print("ReadCompareConfig: Could not open, $compareConfig for reading\n");
			return();
		}
	}		
		
	while (<CONFIG>) {
		chomp;
		my $strippedValue = stripvalue($_);
			
		if (/$item/) {
			($start, $returnSting) = split(/=/, $strippedValue);
			last;				
		}
	}
		
	close(CONFIG);
	
	return($returnSting);
}

########## ReadTestConfig ##########
##
## if it exists, Read <testname>.config and see if $item is specified
## If it is read it in.  Else have it set.
##
##########

sub ReadTestConfig {
	local($testname, $path, $item) = @_;
	
	my $itemfound = 0;
	my $returnSting = "";
		
	if (-e "$path/$testname.config") {
		if (!(open(CONFIG, "<$path/$testname.config"))) {
			print("ReadTestConfig: Could not open, $path/$testname.config for reading\n");
			return("TestConfig Not Found");
		}
		
		while (<CONFIG>) {
			chomp;
			my $strippedValue = stripvalue($_);
			
			if (/$item/) {
				if(/:/){
					($start, $returnSting) = split(/:/, $strippedValue);
				}
				else{
					($start, $returnSting) = split(/=/, $strippedValue);
				}
				$returnSting = stripvalue($returnSting);
				last;				
			}
		}
		
		close(CONFIG);
	}
	
	return($returnSting);
}


########## FindMachineColorCapability ##########
## 
## Accesses the server.config to see if a machine is Full color or Black and White (HLC also).
## 
##########

sub FindMachineColorCapability() {
	my $CONFIG_FILE = "/opt/XRXnps/configuration/server.config";
	my $junk = "";
	my $colorcap = "";
	
	open(SERVERCONFIG, "<$CONFIG_FILE")
			or die "FindMachineColorCapability: Can't open file $CONFIG_FILE for reading\n";
			
	while(<SERVERCONFIG>) {
		chomp;
		if (/Printer Color Capability/) {
			($junk, $colorcap) = split(":", $_);
			last;
		}
	}
	
	close(SERVERCONFIG);
	
	$colorcap = stripvalue($colorcap);
				
	if ($colorcap =~ /FC/) {
		$colorcap = "FC";	
	}
	elsif (($colorcap =~ /HC/) || ($colorcap =~ /HLC/)) {
		$colorcap = "HLC";	
	}
	else {
		$colorcap = "BW";		
	}
	
	return($colorcap);
}

########## FindConfigEntry ##########
## 
## Accesses the server.config to see what value the given config entry currentl has
## 
##########

sub FindConfigEntry {
	local( $configEntry ) = @_;
	
	my $CONFIG_FILE = "/opt/XRXnps/configuration/server.config";
	my $junk = "";
	my $colorcap = "";
	
	open(SERVERCONFIG, "<$CONFIG_FILE")
			or die "FindConfigEntry: Can't open file $CONFIG_FILE for reading\n";
			
	while(<SERVERCONFIG>) {
		chomp;
		if (/$configEntry/) {
			($junk, $entryValue) = split(":", $_);
			last;
		}
	}
	
	close(SERVERCONFIG);
	
	$entryValue = stripvalue($entryValue);
	
	return($entryValue);
}

########## FindSpecificConfigEntry ##########
## 
## Accesses the server.config to see what value the given config entry current has
## 
##########

sub FindConfigSectionEntry {
	local( $configSection, $configEntry, $configFile) = @_;
		
	my $junk = "";
	my $configSectionFound = 0;
	my $entryValue = "";
	
	if ($configFile eq "") {
		$configFile = "/opt/XRXnps/configuration/server.config";
	}
	
	open(SERVERCONFIG, "<$configFile")
			or die "FindConfigEntry: Can't open file $configFile for reading\n";
			
	while(<SERVERCONFIG>) {
		chomp;
		if (/\[$configSection\]/) {
			$configSectionFound = 1;
			next;
		}
		
		if (($configSectionFound == 1) && (/$configEntry/)) {
			($junk, $entryValue) = split(":", $_);
			$entryValue = stripvalue($entryValue);
			last;
		}
		
		if (($configSectionFound == 1) && (/\[/)) {
			last;
		}
	}
	
	close(SERVERCONFIG);
		
	return($entryValue);
}


########## SetFontSubstitution ##########
## 
## Accesses the server.config to see if a machine has Font Substitution enabled.
## 
##########

sub SetFontSubstitution() {
	my $CONFIG_DIR = "/opt/XRXnps/configuration";
	my $CONFIG_FILE = "$CONFIG_DIR/server.config";
	my $fontName = "";
	my $fontpolicyset = 0;
	my $tmpCfgFile = "/tmp/server.config.art";	

	open(SERVERCONFIG, "<$CONFIG_FILE")
			or die "SetFontSubstitution: Can't open file $CONFIG_FILE for reading\n";
			
	open(SERVERCONFIGNEW, ">$tmpCfgFile")
			or die "SetFontSubstitution: Can't open file $CONFIG_FILE.new for writing\n";
						
	while(<SERVERCONFIG>) {
		chomp;
		if (/^SubstituteFont/) {		
			($junk, $fontName) = split(":", $_);
						
			$fontName = stripvalue($fontName);
						
			if ($fontName =~ /^[A-Za-z0-9]+/) {
				print(SERVERCONFIGNEW $_); print(SERVERCONFIGNEW "\n");
				last;
			}
			else {
				print(SERVERCONFIGNEW "SubstituteFont: Courier\n");
				$fontpolicyset = 1;
			}
		}
		else {
			print(SERVERCONFIGNEW $_); print(SERVERCONFIGNEW "\n");
		}
	}
	
	close(SERVERCONFIG);
	close(SERVERCONFIGNEW);
	
	if ($fontpolicyset == 1) {
		if (!(-e "$CONFIG_DIR/server.config.orig")) {
			system("$EXEC_ANY /usr/bin/cp $CONFIG_FILE $CONFIG_DIR/server.config.orig");
		}
		
		system("$EXEC_ANY /usr/bin/cp $tmpCfgFile $CONFIG_FILE");
		system("$EXEC_ANY /usr/bin/chmod 644 $CONFIG_FILE");
		
		system("$EXEC_ANY /net/rio/jump/scripts/configdoctor/updateConfig > /dev/null");
	}
	system("/usr/bin/rm $tmpCfgFile");
	
	return($fontpolicyset);
}


########## CheckDocuSP ##########
## 
## Checks to see if Docusp is Dead
##
##########

sub CheckDocuSP() {
	my $exitStatus = 0;
	my $docuSPDied = 0;
	my $docuspStatus = 0;
	
	### Check to see if Docusp is up
	my $binPath = pwhich('DocuSPstatus.rb');
	chomp($binPath);
			
	if ($binPath eq undef) {
		my $newPath = 
            "$FindBin::Bin/../ruby/bin:/net/lafawnduh/opt/citd_auto/ruby/bin:" 
						. $ENV{'PATH'};
		$ENV{'PATH'} = $newPath;
		$binPath = pwhich('DocuSPstatus.rb');
		chomp($binPath);
	}
		
	$docuspStatus = system("$EXEC_ANY $binPath --active");
	$docuspStatus = $docuspStatus >> 8;
	
	print("CheckDocuSP: docuspStatus = $docuspStatus\n");

	$docuspDied = `$binPath --checkDead`;
	
	if ($docuspDied == 1) {
		
		$docuspProcess =  `$binPath --whoDied`;
		
		if( $docuspProcess =~ /http process died/ || $docuspProcess =~ /ipp process died/ || $docuspProcess =~ /HTTP process died/ || $docuspProcess =~ /IPP process died/ || $docuspProcess =~ /IPDS process died/ || $docuspProcess =~ /analyzePDF_start_server/) {
			$exitStatus = "0";
			print("CheckDocuSP: Will be restarting at the next opportunity for the following reason: $docuspProcess\n");
			system("/bin/touch /tmp/ARTFORCERESTART");
		}
		elsif ($docuspProcess =~ /ppr_shim process died/) {
			print("docuspProcess = $docuspProcess\n");
			$exitStatus = "-5";
		}
		else {
			print("docuspProcess = $docuspProcess\n");
			$exitStatus = "-2";
		}
	}
	
  	if ($docuspStatus == 0) {
	
    		$exitStatus = "-3";
  	} 
	
	### double check that bufmgr main is up, because it hasn't been reporting that it is crashing on 2c54
	if ($exitStatus eq "0") {
		my $ids_output = `/bin/pgrep bufmgrmain`;
		@ids = split("\n", $ids_output);
	
		if ($#ids < 0) {
	
			print("CheckDocuSP: bufmgrmain is down!!!\n");
			system("/bin/touch /tmp/ARTFORCERESTART");
			$exitStatus = "-4";
		
		}
	}	
	
	print("CheckDocuSP: exitStatus = $exitStatus\n");
	
	return($exitStatus);
}


########## killpprprocesses ##########
## 
## If ppr_shim is dead, we need to kill off
## ppr processes to get restart to work.
##
##########

sub killpprprocesses() {

	my $ppr_ids = `/bin/pgrep ppr`;
	my @ids = split("\n", $ppr_ids);
	
	### Take down preflight no mater what.
	
	if ($#ids > -1) {
	
		printf("killpprprocesses: Killing off all ppr processes because ppr_shim died.\n");
	
		foreach $id  (@ids) {
			system("$EXEC_ANY /bin/kill -9 $id");
		}
	
	}
}

########## checkformorethanpreflight ##########
## 
## A workaround for a problem we are seeing.
##
##########

sub checkformorethanpreflight() {

	my $ids_output = `/bin/pgrep preflight`;
	my @ids = split("\n", $ids_output);
	
	### Take down preflight no mater what.
	
	if ($#ids > -1) {
	
		printf("checkformorethanpreflight: More than 1 preflight, killing off all\n");
	
		foreach $id  (@ids) {
			system("$EXEC_ANY /bin/kill -9 $id");
		}
	
	}

	### taking out for now. James tells me things get stuck and not happy if I kill too much.
	# else {
		### if no preflight must be something else stuck.
		### let's just kill everything.
		### well ok, just jc, jpm, and fom.  May be stuck on oa.
		
	#	my @othersToKill = [ "jc", "jpm", "fom" ];
		
	#	foreach $processName (@othersToKill) {
	#		
	#		my $other_ids = `/bin/pgrep $processName`;
	#		@ids = split("\n", $other_ids);	
	#		
	#		if ($#ids > -1) {
	#			foreach $id  (@ids) {
	#				printf("killing $processName, id = $id\n");
	#				system("$EXEC_ANY /bin/kill -9 $id");
	#			}			
	#		}		
	#	}
	# }
}

########## RestartDocuSP ##########
## 
## Checks to see if Docusp is Dead
##
##########

sub RestartDocuSP() {
	my $status = 0;
  
 	my $restartDSPandWait = pwhich('restartDSPandWait');
	chomp($restartDSPandWait);
	
	my $waitForDSPActive = pwhich('WaitForDSPActive.rb');
	chomp($waitForDSPActive);
			
	if (($restartDSPandWait eq undef) or ($waitForDSPActive eq undef)) {
		my $newPath = 
            "$FindBin::Bin/../bin:/net/lafawnduh/opt/citd_auto/bin:" . $ENV{'PATH'};
		$ENV{'PATH'} = $newPath;
		
		if ($restartDSPandWait eq undef) {
			$restartDSPandWait = pwhich('restartDSPandWait');
			chomp($restartDSPandWait);
		}
		
		if ($waitForDSPActive eq undef) {
			$waitForDSPActive = pwhich('WaitForDSPActive.rb');
			chomp($waitForDSPActive);
		}		
	}
	
	print("RestartDocuSP will be using (wait): $waitForDSPActive\n");
	print("RestartDocuSP will be using (restartAndwait): $restartDSPandWait\n");
	
	my $firstTry = 1;
	
	LOOPRESTART: {
	
  		system("$EXEC_ANY $restartDSPandWait 450");
		$status = CheckDocuSP();
	
		if ($status != 0) {
			### Wait A little bit longer and then return real status.
			### For wimpy1 when being really slow.
			
			print("RestartDocuSP: Waiting a little Longer\n");
			system("$EXEC_ANY $waitForDSPActive 450");
		
			$status = CheckDocuSP();
		}
		else {
			$status = 0;
		}
		
		if ($status == -5) {
			killpprprocesses();
		}
	
		if (($status != 0) and ($firstTry == 1)) {
			$firstTry = 0;
			checkformorethanpreflight();
			print("RestartDocuSP: Going To Try to Restart Again....\n");
			goto LOOPRESTART;
		}
		elsif (($status != 0) and ($firstTry == 0)) {
			print("RestartDocuSP: This stinks, Docusp not responding.....\n");		
		}
		
	}
	
  	return($status);
 
}

########## CheckQueuesAreAvailable ##########
## 
## Checks to see if there are Queues on the machine
##
##########

sub CheckQueuesAreAvailable() {

	# my $queueList = `$EXEC_ANY $machineSpecificBinDir/listq -a`;
	my $queueList = listq();
	
	if ($queueList eq "") {
		print("CheckQueuesAreAvailable: Queues are Not Recognized By Docusp.  $queueList\n");
		return(0);
	}
	else {
		print("CheckQueuesAreAvailable: Queues = $queueList\n");
		return(1);
	}
}


########## EnsureDocuSPisUp ##########
## 
## Checks to see if Docusp is Dead
##
##########

sub EnsureDocuSPisUp() {
 	my $notReady=1;
  	my $status=0;
  	my $initialTimeout=120;
  	my $restartStatus=0;
  
	while ($notReady == 1 && $initialTimeout > 0) {
    	$status = CheckDocuSP();
		print("EnsureDocuSPisUp: status is: $status\n");
		
    	if ($status == -2) {
      		print("EnsureDocuSPisUp: DSP is down, will attempt restart\n");
      		last;
    	}
    	elsif ($status == -3) {
      		print("EnsureDocuSPisUp: DSP not activated yet, waiting...\n");
    	}
    	else {
      		print("EnsureDocuSPisUp: DSP is up!\n");
      		$notReady = 0;
    	}
		
    	sleep(5);
    	$initialTimeout -= 5;
  	}

  	if ($notReady == 1) {
    	$status = RestartDocuSP();
    	print("EnsureDocuSPisUp: Restart attempted, status is: $status\n");
		
		### remove ARTFORCERESTART on successful restart
		### so we don't restart again, if we really don't 
		### have to.
		if (($status == 0) && (-e "/tmp/ARTFORCERESTART")) {
			system("rm -f /tmp/ARTFORCERESTART");
		}
  	}
	
  	return($status);
}

########## ReadInOutloadInfo ##########
## 
## Reads contents of /tmp/ARTOUTLOADINFO.txt and returns
## /tmp/ARTOUTLOADINFO.txt is generated by artoutload
##
##########

sub ReadInOutloadInfo() {
	$returnLine = "";
	
	if (!open(OUTLOADINFO, "</tmp/ARTOUTLOADINFO.txt")) {
		print("ReadInOutloadInfo: Could not open, /tmp/ARTOUTLOADINFO.txt, for reading.\n");
		return("No ARTOUTLOADINFO.txt found, Look in /export/home/ftphome/dataXfer/debugLogs for outloads");
	}
		
	while (<OUTLOADINFO>) {
		chomp($_);
		$returnLine = $returnLine . " " . $_;
	}
	
	close(OUTLOADINFO);
	
	return($returnLine);
}


########## checkLog ##########
## 
## Gets a few more tidbits from the system log and displays
## or logs the info.  To Make debug a little nicer.
## 
##########
sub checkLog() {
	my $miscMethods = pwhich("MiscMethods.rb");
	chomp($miscMethods);
	
	printf("checkLog: miscMethods = $miscMethods\n");
				
	if ($miscMethods ne " ") {
		system("$EXEC_ANY $miscMethods checkLog /opt/XRXnps/log/system_log 'process died! Its process id'");
		system("$EXEC_ANY $miscMethods checkLog /opt/XRXnps/log/system_log 'oa memory remaining'");
		system("$EXEC_ANY $miscMethods checkLog /opt/XRXnps/log/system_log 'System will automatically restart'");
	}
	else {
		system("$EXEC_ANY $citd_ruby_bin/MiscMethods.rb checkLog /opt/XRXnps/log/system_log 'process died! Its process id'");
		system("$EXEC_ANY $citd_ruby_bin/MiscMethods.rb checkLog /opt/XRXnps/log/system_log 'oa memory remaining'");
		system("$EXEC_ANY $citd_ruby_bin/MiscMethods.rb checkLog /opt/XRXnps/log/system_log 'System will automatically restart'");
	}
}

########## TakeOutload ##########
## 
## Creates an outload.
## Sends Note to User that Outload was taken if $sendmail = 1
## 
##########

sub TakeOutload() {
	local($suitename, $testname, $sendmail, $hostname) = @_;
	my $message = "NO /tmp/ARTOUTLOADINFO.txt found.";
	my $logFile = "none";
	my $logPath = ReadCompareConfig(".","LogDir");
	my $take_outload = ReadCompareConfig(".","Take_Outload");
	my $logDir = "$logPath/$suitename/$testname";
	
	if ($ms_unittest == 0) {
		checkLog();
	}
		
	if ($take_outload == 1) {
		
		my $outloadscr = pwhich('artoutload');
		chomp($outloadscr);
		
		### assumes if you are running this script you
		### must already have the perl directory on
		### your path.

	  	system("$EXEC_ANY $outloadscr $suitename $testname");
		
		if (-e "/tmp/ARTOUTLOADINFO.txt") {
			$message = ReadInOutloadInfo();	
			system("rm /tmp/ARTOUTLOADINFO.txt");
		}
		
		if (-e "/opt/XRXnps/log/corefiles.pstack") {
			my %machInfo = getDocuSPMachineInfo();
			my $timestamp = `date '+%m.%d.%y_%H:%M:%S'`;
			chomp($timestamp);
			$logFile = "$logPath/$suitename/$testname/$machInfo{'host_name'}" . "_" . "$timestamp" . "_" . "$machInfo{'DocuSP_build_version'}" . "_" . "$machInfo{'DocuSP_IOT_type'}.corefiles.pstack";

			printf("TakeOutload: logPath = $logPath\n");				
			printf("TakeOutload: logFile = $logFile\n");
			printf("logDir = $logPath/$suitename/$testname\n");
									
			if (!(-d "$logDir")) {
				printf("TakeOutload: mkdir -p -m 0777 $logDir");
				system("mkdir -p -m 0777 $logDir");
			}
										
			system("cp /opt/XRXnps/log/corefiles.pstack $logFile");
							
			my $loglink = $citd_auto_logs;
			my $newlink = "http://lafawnduh.ppdev.mc.xerox.com/logs";
		
			if ( $logFile =~ /$loglink/ ) {
				my $tmpLogFile = $logFile;
				$tmpLogFile =~ s/$loglink/$newlink/;
				$logFile = $tmpLogFile;
			}
		}
		
		$wait_after_outload = ReadCompareConfig(".","Wait_After_Outload");
		if( $wait_after_outload == 1 ) {
			sleep();
		} 
		
		if (opendir(COREDIR, "/var/spool/XRXnps/corefiles")) {
			@allfiles = grep !/^\.\.?$/, readdir COREDIR;
			closedir(COREDIR);
			
			foreach $file (@allfiles) {
				system("$EXEC_ANY /usr/bin/rm -rf /var/spool/XRXnps/corefiles/$file");
			}
		}
	}
	else {
	  print("TakeOutload: not taking outload due to Compare_job.config setting.\n");
	}
	
	if ($sendmail == 1) {
		my $Email_Address = ReadTestConfig($testname, "." , "Email_Address");

		if ($Email_Address eq "") {
			$Email_Address = ReadCompareConfig("." , "Email_Address");
		}
		
		if (-e "/opt/XRXnps/log/corefiles.pstack") {
			$extramessage = `cat /opt/XRXnps/log/corefiles.pstack`;
			$mailmessage = $message . "\n\n\nPSTACK DATA:\n\n" . $extramessage;
		}
		else {
			$mailmessage = $message;
		}
		
		if ($Email_Address eq "") {
			system(`sendmail.pl -n "$mailmessage" -u $Email_Address -sub "ART Outload Taken for $suitename:$testname on $hostname."`);
		}
		else {
			system(`sendmail.pl -n "$mailmessage" -u $Email_Address -sub "ART Outload Taken $suitename:$testname on $hostname"`);
		}
	}
		
	return($message, $logFile)
}


########## GetJobCount ##########
## 
## Counts the number of Jobs in a _list.txt file.
## and returns count.
## 
##########

sub GetJobCount() {
	local($listfile) = @_;
	
	my $jobCount = 0;
	my $lookNow = 0;
	my $hopefulLine = "";
	my $currentline = "";

	if (!(open(JOBFILE, "<$listfile"))) {
		print("GetJobCount: Unable to open $listfile\n");
		return(-1);
	}
	else {
		while(<JOBFILE>) {
			chomp;
			$currentline = stripvalue($_);
			next if ($currentline =~ /^\W*$/);
			next if ($currentline =~ /^%%%%/);
				
			if ($currentline =~ /Job_Number/) {
				$lookNow = 1;
			}
			elsif ($lookNow == 1) {
				$hopefulLine = ($currentline =~ /^\W*(\d+)\W*.*$/);
				
				if ($hopefulLine != "") {
					$jobCount++;
				}
				else {
					$hopefulLine = ($currentline =~ /^\W*([a-zA-Z]+)\W*.*$/);
				
					if ($hopefulLine != "") {
						$lookNow = 0;
					}	
				}
			}
			else {
				$hopefulLine = ($currentline =~ /^\W*([a-zA-Z]+)\W*.*$/);
								
				if ($hopefulLine != "") {
					$lookNow = 0;
				}
			}
		}
		
		close(JOBFILE);
	}
	
	return($jobCount);
}


########## GetJobList ##########
## 
## Counts the number of Jobs in a _list.txt file.
## and returns count.
## 
##########
sub GetJobList() {
	local($listfile) = @_;
	
	my $jobCount = 0;
	my $lookNow = 0;
	my $hopefulLine = "";
	my $currentline = "";
	my $jobindex = "";
	my $jobname = "";
	my $dontcare = "";
	my $queuename = "";
	my @jobsInList = ();
	my $jobNameWithIndex = "";
	
	if (!(open(JOBLIST, "<$listfile"))) {
		print("GetJobList: Unable to open $listfile\n");
		return(@jobsInList);
	}
	else {
		while(<JOBLIST>) {
			chomp;
			$currentline = stripvalue($_);
			next if ($currentline =~ /^\W*$/);
			next if ($currentline =~ /^%%%%/);
			
			$currentline =~ s/(\s+)/\t/g;		### replace spaces with a tab
										
			if ($currentline =~ /Job_Number/) {
				$lookNow = 1;
			}
			elsif ($lookNow == 1) {
			
				$hopefulLine = ($currentline =~ /^\W*(\d+)\W*.*$/);
				
				if ($hopefulLine ne "") {
					($jobindex, $queuename, $jobname, $dontcare) = split(/[\t,\n]/, $currentline, 4);
										
					if ($number =~ /^[\d]*$/) {
						$jobNameWithIndex  = $jobindex . "_" . $jobname;
						push(@jobsInList, $jobNameWithIndex);	
		
						$jobCount++;
					}
				}
				else {
					$hopefulLine = ($currentline =~ /^\W*([a-zA-Z]+)\W*.*$/);
				
					if ($hopefulLine ne "") {
						$lookNow = 0;
					}	
				}
			}
			else {
				$hopefulLine = ($currentline =~ /^\W*([a-zA-Z]+)\W*.*$/);
								
				if ($hopefulLine ne "") {
					$lookNow = 0;
				}
			}
		}
		
		close(JOBLIST);
	}
	
	return(@jobsInList);
}


########## GetInfoIndicatorFile ##########
##
##  Takes an indicator location dir, and the machine name
##  calls ruby code which returns the contents of the file
##  if it exists $indicatorExists will be set.
##  else it indicates the file is not there.
##   
##########

sub GetInfoFromIndicatorFile {
	local($indicatorLocation, $machineName) = @_;
	
	$binPath = pwhich('XMLIndicator.rb');
	chomp($binPath);
	
	if (($binPath == undef) or ($binPath eq "")) {
		$binPath = "/net/lafawnduh/opt/citd_auto/bin/XMLIndicator.rb"
	}	
	
	$cmd = "$binPath -i -n $machineName -d $indicatorLocation";
	print("\n$cmd\n");
			
	my $indicatorInfo = `$cmd`;
	
	($indicatorExists, $xmlOutputDir, $xmlfilename, $logdir) = split(/:/, $indicatorInfo, 4);
	
	return($indicatorExists, $xmlOutputDir, $xmlfilename, $logdir);
}


########## PutDataInXMLFile ##########
##
##	Inputs:
##		$xmlfile = file with path to write xml out to.
##		$suiteInfo = suiteName;NumberOfTests;Failures;Errors
##		$testInfo = Testname;Status;MachineName;Time
##		$link = link to html (ie... http://machine/directory)
##		$logDir = location of logs
##   
##########

sub PutDataInXMLFile {
	local($xmlfile, $suiteInfo, $testInfo, $link, $logDir, $append) = @_;
	%machInfo = getDocuSPMachineInfo();
	$IOT_type = $machInfo{'DocuSP_IOT_type'};
	
	$binPath = pwhich('GenerateXML.rb');
	chomp($binPath);
	$cmd = "$binPath -f $xmlfile -s '$suiteInfo' -t '$testInfo' -l $link -d '$logDir' -i '$IOT_type' -a";
	print("\n$cmd\n");
			
	system("$cmd");
}


########## getLastHTMLNameAndStatus ##########
##/ 
##   moved from sendmail.pl so ART_Compare.pl can use it.
##  /tmp/lastHTMLandStatus.txt should have the output from Compare_Job.pl.real
##  it's in the form of  "HTMLNAME:suiteStatus"
##  open file and get the necessary info
##  return(html,status); 
##
##########

sub getLastHTMLNameAndStatus {
	local($htmlAndStatusFile) = @_;
	
	open(HTMLSTATUSFILE, "<$htmlAndStatusFile")
		or die "Couldn't open file: $htmlAndStatusFile for reading. \n";
		
	### line should be of "HTMLNAME:suiteStatus"
		
	my $onlyline = <HTMLSTATUSFILE>;
	chomp($onlyline);	
	close(HTMLSTATUSFILE);
	
	@infoArray = split(";",$onlyline, 5);
	
	### lastHTMLName, suitestatus, email address, suitename:testnme, logfile
	return($infoArray[0], $infoArray[1], $infoArray[2], $infoArray[3], $infoArray[4]);
}


########## calcTestDuration ##########
##
## returns duration of test
##
##########

sub calcDuration {
	local($startFile) = @_;
	my $totalTime = 0;
	my $returnTime = "00:00:00";
	my $curTime = time();
	my $hours = 0;
	
	if (open(STARTFILE, "<$startFile")) {
		$startTime = <STARTFILE>;
		close(STARTFILE);
		chomp($starttime);
						
		$totalTime = $curTime - $startTime;
		
		print("t: $totalTime, c: $curTime, s: $startTime\n");
		$hours = int($totalTime / 3600);
		my $mins = int(($totalTime % 3600) / 60);			
		my $secs = ($totalTime % 3600) % 60;	
		
		print("calcDuration: $hours, $mins, $secs\n");
		
		$returnTime = sprintf("%d:%2.2d:%2.2d", $hours, $mins, $secs);
	}
	else {
		print("calcDuration: unable to open $startFile\n");
	}
		
	return($returnTime);
}


########## ScheduleRestart ##########
##
## schedule ART Tests to restart before running.
##
##########

sub ScheduleRestart {
  print("Scheduling a DocuSP restart\n");
  system("touch /tmp/ARTFORCERESTART");
  system("chmod 777 /tmp/ARTFORCERESTART");
}

########## RestartScheduled ##########
##
## see if a restart was scheduled.
##
##########

sub RestartScheduled() {
  return (-e "/tmp/ARTFORCERESTART" );
}

########## determineUserName ##########
##
##########
sub determineUserName() {
	my  $userName = `/usr/ucb/whoami`;
	chomp ($userName);

	if ($userName eq "root") {
		$userName = $ENV{'USER'};
		chomp($userName);
	}

	if (($userName eq "autouser") || ($userName eq "") || ($userName eq "xrxusr")) {
		$userName = "scorpio";
	}
	
	return($userName);
}

########## findCompareConfig ##########
##
## returns location of Compare_Job.config
## Only 3 possible choices.
## 	1) Current directory takes precedent
##  2) /home/username/artconfig takes next
## 	3) last is on lafawnduh
##
##########

sub findCompareConfig() {
	my $path = "$CITD_CONFIG_DIR/Compare_Job.config";
	my $username = determineUserName();

	if (-e "./Compare_Job.config") {
		$path = "./Compare_Job.config";
	}
	elsif (-e "/home/$username/artconfig/Compare_Job.config") {
		$path = "/home/$username/artconfig/Compare_Job.config";
	}
		
	return($path);
}

##################################################################
# Uses a ruby program "CheckFileType.rb", to look inside of a _list.txt
# or zip file and returns 0 if the file extension could not be found in
# the file or a 1 if it was.
######################################################################
sub HasFileType {
	local($filename, $ext) = @_;
	my $checkForFileType = findRubyExecutable("CheckFileType.rb");
	system("$checkForFileType -t -f $filename -e $ext");
	my $retVal = $? >> 8;
	return $retVal;
}

##################################################################
# Uses a ruby program "CheckFileType.rb", to look inside of a _list.txt
# or zip file and returns 0 if the file extension could not be found in
# the file or a 1 if it was.
######################################################################
sub HasRogueFileTypes {
	local($filename) = @_;
	my $checkForRogueFileType = findRubyExecutable("CheckFileType.rb");
	system("$checkForFileType -r -f $filename");
	my $retVal = $? >> 8;
	return $retVal;
}

##################################################################
# Uses a ruby program "listq.rb" to get list of tv files
# available in /opt/XRXnps/configuration/Queues
######################################################################

sub listq {
	my $listqEXE = findRubyExecutable("listq.rb");
	print("$EXEC_ANY $listqEXE\n");
	my $queueList = `$EXEC_ANY $listqEXE` ;
	return $queueList;
}

1;
