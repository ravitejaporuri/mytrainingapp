#!/usr/bin/perl
#

use Fcntl;
use FindBin;
use File::Path;

use lib "$FindBin::Bin";
require "miscsubroutines.pl";

########## GOBALS ##########

umask(000);

my $machineType = `mach`;
chomp($machineType);
my $OS = `uname -s`;
chomp($OS);

my $OSRev = `uname -r`;
chomp($OSRev);

my $machineSpecificBinDir = "bin.$OS-$OSRev-$machineType";
print("my machinedir: $machineSpecificBinDir\n");
my $EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";


##############################################################
#################### START SUBROUTINES #######################
##############################################################

########## deletealljobs ##########
## 
## calls "job deleteall" and waits until all the jobs have been deleted 
## 
##########
sub deletealljobs(){
	
	set_tools_path();
	
	@queueArray = get_queues();
	
	# try for 5 minutes to delete all the jobs, should work first time but this will slow it down
	# in the case where the machine is bogged down and may take a few seconds to cleanup
	# if we don't do this the machine may send more jobs before the others cleaned up
	
	my $keepgoing = 60;
	my $jobleft = 0;
	my $deletealljobsresult = -1;
	
	while ( $keepgoing > 0 ) {
	
		### For each queue, delete the jobs
		foreach $queue (@queueArray) {
	        	#print "deleting $queue\n";
			system ( "$EXEC_ANY $jobpath deleteall $queue" );
		}
		
		#see if any jobs are left
		$jobsleft = `$jobpath list | sed 's/^[ \t]*//' | wc -l | tr -s ' ' ',' | cut -f2 -d,`;
		print "Deleting Jobs, Jobs Left: $jobsleft\n";
				
		#if no jobs are left exit, else retry
		if( $jobsleft == 0 ){
			$keepgoing = 0;
			$deletealljobsresult = 0;
		}
		else{
			$keepgoing--;
			sleep(5);
		}
	}
	
	return $deletealljobsresult;

}

########## get_queues ##########
##
## Return an array of queues currently on the machine
##
##########
sub get_queues(){

	set_tools_path();
	
	my $machSpecBinDir = "$FindBin::Bin/../bin.$OS-$OSRev-$machineType";

	### Get List of all Queues. String Format QueueName1:QueueName2:Queuename3:...
	### Cannot pwhich listq, we use a special listq that has an -a option
	# $queueList = `$EXEC_ANY $machSpecBinDir/listq -a`;
	my $queueList = listq();
		
	chomp($queueList);
	@queueArray = split(":", $queueList);
	return @queueArray
}

sub set_tools_path(){

	$perftools = $machineType . "_tools";

	if (!($ENV{'PATH'} =~ /$machineSpecificBinDir/)) {
		$newPath = "/net/lafawnduh/opt/citd_auto/$machineSpecificBinDir/" . ":" . $ENV{'PATH'};
		$ENV{'PATH'} = $newPath;
	}

	if (!($ENV{'PATH'} =~ /$perftools/)) {
		$newPath ="/performance/tools/$perftools/" . ":" . $ENV{'PATH'};
		$ENV{'PATH'} = $newPath;
	}

	if (!($ENV{'PATH'} =~ /citd_auto\/config/)) {
		$newPath = "/net/lafawnduh/opt/citd_auto/config/" . ":" . $ENV{'PATH'};
		$ENV{'PATH'} = $newPath;
	}

	### Add Perl directory
	if (!($ENV{'PATH'} =~ /citd_auto\/perl/)) {
		#$newPath = "/net/lafawnduh/opt/citd_auto/perl/" . ":" . $ENV{'PATH'};
		$newPath = $ENV{'PATH'} . ":/net/lafawnduh/opt/citd_auto/perl/" 
                          . ":/net/lafawnduh/opt/citd_auto/perl/";
		$ENV{'PATH'} = $newPath;
	}



	$jobpath = pwhich('job');
	chomp $jobpath;
	$listqpath = pwhich('listq');
	chomp $listqpath;

}


if ( __FILE__ eq $0 ) {
##############################################################
######################## START MAIN ##########################
##############################################################

set_tools_path();

deletealljobs();



##############################################################
######################### END MAIN ###########################
##############################################################
}
else {
	1;		### File is being required, probably for Unit testing.
}
