#!/usr/bin/perl -I/net/lafawnduh/opt/citd_auto/perl -w
#
# sendmail.pl
#
# 1) Will install necessary files on the system if necessary
#
# 2) Sends a mail message with the last html generated to the current user.
#
#

use Fcntl;
use FindBin;

use lib "$FindBin::Bin";

require "miscsubroutines.pl";

my $doInstall = "-1";
my $sendMail = "-1";
my $lastHTMLName = "";
my $suiteStatus = 0;
my $notifyUser = -1;
my $message = "";
my $userEmail = "";
my $subject = "";
my $logfile = "";
my $htmlAndStatusFile = "/tmp/lastHTMLandStatus.txt";		### defined at end of Compare_Job.pl.real

my $machineType = `mach`;		# i386 or sparc, used for installing sendmail
chomp($machineType);
my $os = `uname -r`;			# only for now installing on solaris 10.

my $host_name =`hostname`;
chomp($host_name);

my  $userName = `/usr/ucb/whoami`;
chomp ($userName);

if ($userName eq "root") {
	$userName = $ENV{'USER'};
	chomp($userName);
}

if (($userName eq "autouser") || ($userName eq "") || ($userName eq "xrxusr")) {
	$userName = "scorpio";
}

########## installSendMail ##########
##
## Checks files and installs the stuff necessary for sendmail
##
##########

sub installSendMail() {
	if ($os == 5.10) {
		### make changes to resolve.conf
		
		if (!(-e "/etc/resolv.conf.ismbackup")) {
			`cp /etc/resolv.conf /etc/resolv.conf.ismbackup`;
		}
		
		### make changes to nsswitch.conf
		if (!(-e "/etc/nsswitch.conf.ismbackup")) {
			`cp /etc/nsswitch.conf /etc/nsswitch.conf.ismbackup`;
		
			### publickey:  files nis
		}
		
		### make changes to sendmail.cf
		if (!(-e "/etc/sendmail.cf.ismbackup")) {
			`cp /etc/mail/sendmail.cf /etc/mail/sendmail.cf.ismbackup`;
		
			if ($machineType eq "i386") {
					;
			}
			else {
					;		
			}
		}
		
		### so system doesn't overwrite .cf (I guess that's because you aren't suppose to modify this).
		`chmod 444 /etc/mail/sendmail.cf`;

		`svcadm restart inetd`;
		`svcadm restart sendmail`;
	
		print("sendmail should now be working!!!\n");
	}
	else {
		print("sendmail should work for older configs - maybe, have no clue!!!\n");
	}
}


########## mail_html_message ##########
##
## Mails Message to user about Test Problem  
##
##########

sub mailNotifyMessage
{
		local ($username) = @_;
		
		if (-e "/tmp/reportmessage.txt") {
			system("rm -f /tmp/reportmessage.txt");
		}
		
        if (!(sysopen( MAIL_TMP, "/tmp/reportmessage.txt", O_WRONLY | O_TRUNC | O_CREAT))) {
			print("mailNotifyMessage: Could not open file: /tmp/reportmessage.txt for writing. \n");
			exit(-1);
		}
		         
        printf ( MAIL_TMP "ART requested this Mail Notification to YOU!!!\n\n");
        printf ( MAIL_TMP "Please Take Appropriate Action!!!\n\n");
		printf ( MAIL_TMP "Message From ART:\n");
		
		if ($message ne "") {
			printf ( MAIL_TMP "     $message !!!\n\n");
		}
		else {
			printf ( MAIL_TMP "     ART is not nice, and did not give me a message(try to be understanding) !!!\n\n");		
		}
        close( MAIL_TMP );
		
		if ($username =~ /@/) {
			$email_address = $username;
		}
		else {
        	$email_address = $username . "\@ppdev.mc.xerox.com";
		}
 
 		if (!("$username" eq "scorpio")) {

 			if ($subject eq "") {       
				system("mailx -r $email_address -s \"$message\" $email_address < /tmp/reportmessage.txt");
			}
			else {
				system("mailx -r $email_address -s \"$subject\" $email_address < /tmp/reportmessage.txt");		
			}
		}
		else {
			printf("Not Sending Mail... It would go to scorpio (You must be root or autoUser or scorpio).... Please run this as yourself!!!!\n");		
		}
		
		if (-e "/tmp/reportmessage.txt") {
			system("rm -f /tmp/reportmessage.txt");
		}
}

########## mail_html_message ##########
##
## Mails html link to specified email address  
##
##########

sub mailHTMLMessage
{
		local ($htmlfile, $suite_status, $username, $suiteTest) = @_;

		if (-e "/tmp/reportmessage.txt") {
			system("rm -f /tmp/reportmessage.txt");
		}
		
        if (!(sysopen( MAIL_TMP, "/tmp/reportmessage.txt", O_WRONLY | O_TRUNC | O_CREAT))) {
			print("mailHTMLMessage: Could not open file: /tmp/reportmessage.txt for writing. \n");
			exit(-1);
		}
		        
		printf ( MAIL_TMP "Test Suite Name: $suiteTest, Machine Host Name: $host_name\n\n");
        printf ( MAIL_TMP "Automated test completed, to review the results select the link below:\n\n");
		
		if ($htmlfile =~ /http:/) {
        	printf ( MAIL_TMP "$htmlfile\n\n");
		}
		else {
        	printf ( MAIL_TMP "http://ci.ppdev.mc.xerox.com/$htmlfile\n\n");		
		}
		
		if ($logfile ne "") {
			printf ( MAIL_TMP "By the way, you can find the Log File at:\n");
			printf ( MAIL_TMP "     $logfile\n");			
		}
		
        close( MAIL_TMP );
		if (!($userName =~ /@/)) {
        	$email_address = $username . "\@ppdev.mc.xerox.com";
		}
		else {
			$email_address = $username;
		}
		
		if (!("$username" eq "scorpio")) {
		
			if (($suite_status eq "0") || ($suite_status =~ /[Pp]ass/)) {
        		system("mailx -r $email_address -s \"ART $suiteTest on $host_name Completed - Passed\" $email_address < /tmp/reportmessage.txt");
			}
			elsif ($suite_status eq "-9") {
        		system("mailx -r $email_address -s \"ART $suiteTest on $host_name Completed - Some Jobs Not Compared\" $email_address < /tmp/reportmessage.txt");				
			}
			else {
        		system("mailx -r $email_address -s \"ART $suiteTest on $host_name Completed - Failed\" $email_address < /tmp/reportmessage.txt");		
			}
		}
		else {
			printf("Not Sending Mail... It would go to scorpio (You must be root or autoUser or scorpio).... Please run this as yourself!!!!\n");
		}
		
		if (-e "/tmp/reportmessage.txt") {
			system("rm -f /tmp/reportmessage.txt");
		}
}


sub print_help() {
	print("sendmail.pl usage:  \n\n");
	print("     Install Mail     -i\n");
	print("     Send Mail        -s\n");
	print("     Notify User      -n <Message>\n");
	print("		User Email       -u <Email Address>\n");
	print("		Subject          -sub <Subject>\n");
	print("     Help             -h\n\n");
	print("Default is to Send Mail!!\n\n");
}


sub ProcessCommandLine() {
	$index = 0;
	foreach $option (@ARGV) {
		OPTIONS: {
			if ($option eq "-h")	{ print_help(); exit; last OPTIONS; }
			if ($option eq "-i")	{ $doInstall = 1; last OPTIONS; }
			if ($option eq "-s")	{ $sendMail = 1; last OPTIONS; }
			if ($option eq "-n") 	{ $notifyUser = 1; $message = $ARGV[$index + 1]; last OPTIONS; }
			if ($option eq "-u")	{ $userEmail = $ARGV[$index + 1]; last OPTIONS; }
			if ($option eq "-sub")	{ $subject = $ARGV[$index + 1]; last OPTIONS; }

			# if any other -word then invalid option
			if ($option =~ /^-.*/) {
				print("Invalid Argument $option \n"); 
				print_help(); 
				exit;			
			}
		}
		$index++;
	}
}


##############################################################
######################## START MAIN ##########################
##############################################################

ProcessCommandLine();

### If neither are selected, default both to true.
if (($doInstall == -1) && ($sendMail == -1) && ($notifyUser == -1)) {
	print_help();	
	exit(0);
}

if ($doInstall == 1)  {
	# installSendMail();
	print("Not Implemented until I get concrete proof that sendmail isn't working an a machine\n");
	print("In other words, it is now working on all machines, for some ungodly reason\n");
}

if ($sendMail == 1) {
	($lastHTMLName, $suiteStatus, $userConfigEmailAddress, $suiteName, $logfile) = getLastHTMLNameAndStatus($htmlAndStatusFile);
		
	if (($userConfigEmailAddress ne "") && ($userConfigEmailAddress ne "default")) {
		$userName = $userConfigEmailAddress;
	}
	
	if ($lastHTMLName ne "") {
		mailHTMLMessage($lastHTMLName, $suiteStatus, $userName, $suiteName);		
	}
}
elsif ($notifyUser == 1) {
	if (($userEmail ne "") && ($userEmail ne "default")) {
		mailNotifyMessage($userEmail);		
	}
	else {
		mailNotifyMessage($userName);	
	}
}

