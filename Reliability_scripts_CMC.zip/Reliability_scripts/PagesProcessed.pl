#!/usr/bin/perl
use File::Basename;
$hostname=`hostname`;
$total_pages=0;
chomp($hostname);
#@queues=system("ls /opt/XRXnps/configuration/Queues/$hostname* | grep -v $hostname"."_");
$cmd="ls /opt/XRXnps/configuration/Queues/$hostname* | grep -v $hostname"."_";
#print $cmd;
@queues=`$cmd`;
## | grep -v barzini_ | sed 's/\/opt\/XRXnps\/configuration\/Queues\///'`;
#print $queues[1];

$num_qs=@queues;
#print $num_qs;

foreach $queue(@queues)
{
$q=basename($queue);
#print basename("$queue");
push(@jobs,`/opt/XRXnps/autoTest/bin/execAny /performance/tools/i386_tools/jobwatch $q`);
}
#print "@jobs";
$num_jobs=@jobs;
foreach $job(@jobs)
{
($jobname,$JobID, $StartT, $SubmissionT, $ProcStartT, $ProcStopT,$PrintStartT,$PrintStopT, $PagesPrinted, $PagesRipped,$BytesRipped)=split(",",$job);
$total_pages=$total_pages+$PagesRipped;
}
print $total_pages;
