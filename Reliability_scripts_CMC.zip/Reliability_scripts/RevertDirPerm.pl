#!/usr/bin/perl
#

use Fcntl;
use FindBin;

use lib "$FindBin::Bin";

########## GOBALS ##########

my $machineType = `mach`;
chomp($machineType);
my $OS = `uname -s`;
chomp($OS);

my $OSRev = `uname -r`;
chomp($OSRev);

my $machineSpecificBinDir = "bin.$OS-$OSRev-$machineType";
print("my machinedir: $machineSpecificBinDir\n");
my $queueList = "";
my @queueArray = ();
my $EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";


##############################################################
#################### START SUBROUTINES #######################
##############################################################


########## Resets permissions of Queue directory ##########
## 
## Resets the permissions of /opt/XRXnps/configuration/Queue
## 
##########

sub RevertChangePerm() {
	my $queDir = "/var/spool/XRXnps/saved";

	if (!(opendir(QUEUEDIR, $queDir ))) {
		print("InputFile Dir, $queDir, Problem\n");
		return(-1);
	}
		
	my @files = grep((!/^\.\.?$/ ), readdir(QUEUEDIR));
	
	closedir(QUEUEDIR);
		
	system("$EXEC_ANY /bin/chmod -R 755 \"$queDir\"");
	
}

##############################################################
######################## START MAIN ##########################
##############################################################

RevertChangePerm();
