#!/usr/bin/perl

use Fcntl;
use FindBin;

use lib "$FindBin::Bin";

my $machineType = `mach`;
chomp($machineType);
my $OS = `uname -s`;
chomp($OS);
my $OSRev = `uname -r`;
chomp($OSRev);
my $machineSpecificBinDir =
"$FindBin::Bin/../bin.$OS-$OSRev-$machineType";

my $curpath = `pwd`;
chomp($curpath);

require "miscsubroutines.pl";

##############################################################
###################### DESCRIPTION ###########################
##############################################################
######### FOR Each ##########
##
## 1. Prints out to log directory/suite/test/logs
## 2. Takes before, if the process already exists (logname_<*_cdf>_umem.before)
## 3. Takes after all tests are submitted and decomposed (logname_<*_cdf>_umem.after)
## 4. Compares differences logname_<*_cdf>_umem.before & logname_<*_cdf>_umem.after in bytes
## 5. Compares differences logname_<*_cdf>_umem.after to master
## 6. Notes information in html/uml/or mail note to user
##
## 7. Master is in the master_jobs directory for each machine.
## 
##########

### Get Each CDF (ps_cdf, pcl5c_cdf, frf_cdf, tiff_cdf, ppr_cdf(?))
### See if CDF has umem on it enabled.

########## FOR Each ##########
### if enabled dump current umem log
### 	1. ::umem_status
###				a. May look at status of Message buffer and see if it's ok.
###		2. ::find_leaks	
###				a.Looks at Number of Bytes leaked.
###	    		b. <address>$<bufctl_audit sorts through find_leaks data, and records stack of each
### 
##########


### Compare Before and After scripts
### Log Data in HTML if needed
### Compare After and Master After scripts
### Log Data in HTML if needed.


##############################################################
######################## GLOBALS #############################
##############################################################
my $bin_dir = "/opt/XRXnps/bin";
my $time_stamp = `date '+%m.%d.%y'`;
chomp($time_stamp);
my $hostname = `hostname`;
chomp($hostname);

########## command line options ##########
my $suite = "";
my $test = "";
my $compare = 0;
my $after = 0;
my $compare = 0;
my $compwhat = "";		### compare what after->before (ab), after->master (am), all.
my $logdir = "/net/ci/d0/test_results/DTRLogs";
my $logpath = "/net/ci/d0/test_results/DTRLogs/AutoPrintReliability/UMEM";
my $binaries = "";


##############################################################
######################## SUBROUTINES #########################
##############################################################


########## PullTotals ##########
##
## Pulls totals for log for each PDF
##
##########

sub PullTotals {
	local($thislog) = @_;
	
	my @totals = ();
	my $process = "";
	my $pid = "";
	my $found = 0;
	my $context;
	
	my $lookForTotal = 0;
		
	if (-e "$thislog") {
		if (!(open(THISLOG, "<$thislog"))) {
			print("PullTotals: could not open, $thislog!!\n");
			return(@totals);	
		}
		
		while(<THISLOG>) {
			chomp();
			if (/^##### UMEM_FINDLEAKS FOR/) {

				if (($lookForTotal == 1) && ($found == 0)) {
					print("PullTotals: Totals for $process:$curpid not found.\n");
					push(@totals, "none");
				}
					
				### Break up PID "##### UMEM_FINDLEAKS FOR $cdf:$pid:$protect:$context"
				($process, $pid, $protect, $context) = (/^##### UMEM_FINDLEAKS FOR (.+):(.+):(.+):(.+) ######$/);
				$lookForTotal = 1;
				$found = 0;
			}
			
			if ((/^.*Total.*$/) && ($lookForTotal == 1)) {
				
				if (/^.*oversized.*$/) {
					push(@totals, "$process:$pid:$protect:$context:oversized:$_");
					$found = 1;
				}
				else {
					push(@totals, "$process:$pid:$protect:$context:normal:$_");
					$found = 1;				
				}	
			}
			
			if (/^########## END/) {

				$lookForTotal = 0;
				if ($found == 0) {
					print("PullTotals (2): Totals for $process:$pid not found.\n");				
				}
			}
		}
						
		close(THISLOG);
	}	
	else {
		print("PullTotals: $thislog does not exists!!\n");
	}
			
	return(@totals);
}

########## CompareTwoUmemLogs ##########
##
## Compares totals and tells user about umem info.
##
##########

sub CompareTwoUmemLogs {
	local($oldumemlog, $newumemlog) = @_;
		
	my @totOldLogs = PullTotals($oldumemlog);
	my @totNewLogs = PullTotals($newumemlog);
	
	my $oldTotCdf = "";
	my $newTotCdf = "";
	
	my $oldcdf = "";
	my $oldpid = 0;
	my $oldinfo = "";
	my $oldtype = "";
	my $oldcontext = "";
	my $oldprotected = "";
	
	my $newcdf = "";
	my $newpid = 0;
	my $newinfo = "";
	my $newtype = "";
	my $newcontext = "";
	my $newprotected = "";
	
	my $newleaksfound = 0;
	
	if (!(open(UMEMRESULTS, ">$logdir/$hostname.umem.$time_stamp.results"))) {
		print("CompareTwoUmemLogs: Could not open $logdir/$hostname.umem.$time_stamp.results for writing\n");
		return();
	}
	
	print(UMEMRESULTS "\n#####################\n");
	print(UMEMRESULTS "Comparing\n");
	print(UMEMRESULTS "   $oldumemlog\n");
	print(UMEMRESULTS " to\n");
	print(UMEMRESULTS "   $newumemlog\n");
	print(UMEMRESULTS "#####################\n");
	print(UMEMRESULTS "\nTime Stamp = $time_stamp\n");

			
	foreach $newTotCdf (@totNewLogs) {
	
		my $found = 0;
		my $newBuffers = 0;
		my $newbytes = 0;
		my $oldBuffers = 0;
		my $oldBytes = 0;
		my $dif = 0;

		print(UMEMRESULTS "\n#####################\n\n");
		print(UMEMRESULTS "Newest Log Info: $newTotCdf\n");
		
		($newcdf, $newpid, $newprotected, $newcontext, $newtype, $newinfo) = split(/:/, $newTotCdf, 6);
			
		foreach $oldTotCdf (@totOldLogs) {
		
			($oldcdf, $oldpid, $oldprotected, $oldcontext, $oldtype, $oldinfo) = split(/:/, $oldTotCdf, 6);
		
		
			if (($oldcdf eq $newcdf) && ($oldtype eq $newtype) && ($oldprotected eq $newprotected) && ($oldcontext eq $newcontext)) {
				
				$found = 1;
				
				print(UMEMRESULTS "Oldest Log Info: $newTotCdf\n");
				
				if ($oldtype eq "oversized") {
					($oldBuffers, $oldBytes) = ($oldinfo =~ /^.*Total\W+(\d+).*oversized leaks\W+(\d+).*bytes.*$/);
					($newBuffers, $newBytes) = ($newinfo =~ /^.*Total\W+(\d+).*oversized leaks\W+(\d+).*bytes.*$/);
				
					### Number of Bytes
					print(UMEMRESULTS "\nBefore: Number of Oversized Leaks = $oldBuffers, Total Bytes Leaked = $oldBytes\n");
					print(UMEMRESULTS "After: Number of Oversized Leaks = $newBuffers, Total Bytes Leaked= $newBytes\n");
				
					if ($oldBuffers < $newBuffers) {
						$dif = $newBuffers - $oldBuffers;
						print(UMEMRESULTS "!!!!! Possible Problem with Oversized Memory Leaks !!!!!\n");
						print(UMEMRESULTS "!!!!! Difference Before - After Oversized Leaks = $newBuffers - $oldBuffers = $dif\n");
						system("echo UMEMRESULTS !!!!! Difference Before - After Oversized Leaks: $newBuffers - $oldBuffers = $dif\n");
						$newleaksfound = 1;
					}
				
					if ($oldBytes < $newBytes) {
						$dif = $newBytes - $oldBytes;
						print(UMEMRESULTS "!!!!! Possible Problem with Oversized Bytes Allocated Leaks !!!!!\n");
						print(UMEMRESULTS "!!!!! Difference Before - After Oversized Bytes Leaked = $newBytes - $oldBytes = $dif\n");
						system("echo !!!!! Difference Before - After Oversized Bytes Leaked = $newBytes - $oldBytes = $dif\n");
						$newleaksfound = 1;
					}
				}
				else {
					($oldBuffers, $oldBytes) = ($oldinfo =~ /^.*Total\W+(\d+).*buffers\W+(\d+).*bytes.*$/);
					($newBuffers, $newBytes) = ($newinfo =~ /^.*Total\W+(\d+).*buffers\W+(\d+).*bytes.*$/);
				
					### Number of Bytes
					print(UMEMRESULTS "\nBefore: Number of Buffers Leaked = $oldBuffers, Total Bytes Leaked = $oldBytes\n");
					print(UMEMRESULTS "After: Of Buffers Leaked = $newBuffers, Total Bytes Leaked = $newBytes\n\n");
				
					if ($oldBuffers < $newBuffers) {
						$dif = $newBuffers - $oldBuffers;
						print(UMEMRESULTS "!!!!! Possible Problem with Umem Buffers Allocated !!!!!\n");
						print(UMEMRESULTS "!!!!! Difference Before - After Buffers Leaked = $newBuffers - $oldBuffers = $dif\n");
						system("echo !!!!! Difference Before - After Buffers Leaked = $newBuffers - $oldBuffers = $dif\n");
						$newleaksfound = 1;
					}
				
					if ($oldBytes < $newBytes) {
						$dif = $newBytes - $oldBytes;
						print(UMEMRESULTS "!!!!! Possible Problem with Umem Bytes Allocated !!!!!\n");
						print(UMEMRESULTS "!!!!! Difference Before - After Bytes Leaked = $newBytes - $oldBytes = $dif\n");
						system("echo !!!!! Difference Before - After Bytes Leaked = $newBytes - $oldBytes = $dif\n");
						$newleaksfound = 1;
					}
				}
				
				last;
			}
		}
		
		if ($found != 1) {
			print(UMEMRESULTS "\n$newcdf:$newprotected:$newcontext Not Found in Older File\n");
			
			if ($newtype eq "oversized") {
				($newBuffers, $newBytes) = ($newinfo =~ /^.*Total\W+(\d+).*oversized leaks\W+(\d+).*bytes.*$/);
				print(UMEMRESULTS "Number of Oversized Leaks = $newBuffers, Number of Bytes Leaked = $newBytes\n");
				system("echo Number of Oversized Leaks = $newBuffers, Number of Bytes Leaked = $newBytes\n");
			}
			else {
				($newBuffers, $newBytes) = ($newinfo =~ /^.*Total\W+(\d+).*buffers\W+(\d+).*bytes.*$/);
				print(UMEMRESULTS "Number of Buffers Leaked = $newBuffers, Number of Bytes Leaked = $newBytes\n\n");
				system("echo Number of Buffers Leaked = $newBuffers, Number of Bytes Leaked = $newBytes\n\n");
			}
		}
	}
	
	print(UMEMRESULTS "#####################\n");
	close(UMEMRESULTS);
	
	system("chmod 666 $logdir/$hostname.umem.$time_stamp.results");
	
	if ($newleaksfound == 1) {
		print("\numem.pl: !!!!! New Leaks Found !!!!!\n");	
	}
	else {
		print("\numem.pl:  New Leaks *Not* Found \n");		
	}
	print("umem.pl: Results are in $logdir/$hostname.umem.$time_stamp.results\n");
	print "Content-type: text/html\n";
}


########## CompareAvailableLogs ##########
##
## Checks to see what logs need to be compared against.
##
##########

sub CompareAvailableLogs {
	local($logfile) = @_;
		
	if (($compwhat eq "ab") || ($compwhat eq "am") || ($compwhat eq "all")) {
	
		if (($compwhat eq "ab") || ($compwhat eq "all")) {

			if (-e "$logfile/$hostname.umem.before") {
				if (-e "$logfile/$hostname.umem.after") {
					CompareTwoUmemLogs("$logfile/$hostname.umem.before", "$logfile/$hostname.umem.after");
				}
				else {
					print("CompareAvailableLogs: Cannot Compare ab, $logfile/$hostname.umem.after missing\n");
				}
			}
			else {
				print("CompareAvailableLogs: Cannot Compare ab, $logfile/$hostname.umem.before missing\n");
			}
		}
	
		if (($compwhat eq "am") || ($compwhat eq "all")) {
			if (-e "$logfile/$hostname.umem.after") {
				if (-e "$logfile/$hostname.umem.master") {
					CompareTwoUmemLogs("$logfile/$hostname.umem.master", "$logfile/$hostname.umem.after");
				}
				else {
					print("CompareAvailableLogs: Cannot Compare am, $logfile/$hostname.umem.after master\n");
				}
			}
			else {
				print("CompareAvailableLogs: Cannot Compare am, $logfile/$hostname.umem.before after\n");
			}	
		}
	}
	else {
		print("CompareAvailableLogs: invalid compare arg, $compwhat\n");	
	}
}


########## DumpUmemStatus ##########
##
## Writes out status to $logfile
## has process leaks look at the data
##
##########

sub DumpUmemStatus {
	local($logfile, $binary) = @_;
		
	my $pid = `pgrep $binary`;
	my $status = $? >> 8;
			
	if ($status == 0) {
		chomp($pid);
		my @pids = split(/\n/, $pid);
		
		foreach $idpid (@pids) {
			my $context = "NA";
			my $protect = "NA";
		
			if ($binary =~ /ps_cdf/) {
				my $commandline = `$EXEC_ANY /usr/bin/ps -o args= -p $idpid`;
				### /opt/XRXnps/bin/ps_cdf.real.real -p PS-PROTECTED -v PS-6135-600x600x8 -f 4054 -
				($protect, $context) = ($commandline =~ /-p\W+([a-zA-Z0-9\-]*)\W+-v\W+([a-zA-Z0-9\-]*)\W+/);
			}

			system(`echo "##### UMEM_STATUS FOR $binary:$idpid ######\n" >> $logfile`);
			system(`echo "::umem_status" | /usr/bin/mdb -p $idpid >> $logfile`);
			system(`echo "##### UMEM_FINDLEAKS FOR $binary:$idpid:$protect:$context ######\n" >> $logfile`);
			system(`echo "::findleaks -d" | /usr/bin/mdb -p $idpid >> $logfile`);
			system(`echo "########## END UMEM_FINDLEAKS FOR $binary:$idpid:$protect:$context ##########\n" >> $logfile`);
		
			system("chmod 666 $logfile");
		}
	}		
}


########## CheckAndDumpUmemStats ##########
##
## Writes out status to $logfile
## has process leaks look at the data
##
##########

sub CheckAndDumpUmemStats() {
	my $cdf = "";
	my $suffix = ".none";
	
	if ($before == 1) {
		$suffix = ".before";		
	}
	else {
		$suffix = ".after";		
	}
	
	system("rm -f $logdir/$hostname.umem$suffix");
	print("CheckAndDumpUmemStats: $logdir/$hostname.umem$suffix\n");
			
	if ($binaries eq "") {
		
		my $tmpbinaries = ReadTestConfig($test, $curpath, "UMEMBinaries");
		$binaries = stripvalue($tmpbinaries);
						
		if (($binaries eq "") || ($binaries eq "TestConfig Not Found")) {
			print("dumpUmemStats: No UMEMBinaries Found in $curpath/$test.config: $!\n");
			print("dumpUmemStats: Using Defaults\n");
			$binaries = "ps_cdf tiff_cdf pcl5c_cdf";
		}
	}
		
	@umemBinaries = split(/ /, $binaries);	
	my $binary = "";
			
	foreach $binary (@umemBinaries) {
		DumpUmemStatus("$logdir/$hostname.umem$suffix", $binary);
	}

##############################################################################
##### to create table for WriteResult file that reflects in html page ########
##############################################################################

open(MY_Header, ">", "/net/ci/d0/test_results/DTRLogs/AutoPrintReliability/UMEM/$hostname.Umem.Log") || die "could not open the file"; 
print MY_Header "<br><br> \n";
print MY_Header "<table border=2 bordercolor=black cellpadding=3 cellspacing=0 style=border-collapse: collapse> \n";
print MY_Header "<caption><b>MEMORY LOG</b></caption> \n";
print MY_Header "<tr> \n";
print MY_Header "<td align=center bgcolor=DDDDDD font size=4 style='bold; font-weight:bold'> Log Name  </td> \n";
print MY_Header "<td align=center bgcolor=DDDDDD font size=4 style='bold; font-weight:bold'> Log File  </td> \n";
print MY_Header "</tr> \n";
print MY_Header "<tr> \n";
print MY_Header "<td align=left bgcolor=FFFF99> Memory Leakages before running Reliability test  </td> \n";
print MY_Header "<td align=left bgcolor=FFFF99><a href='http://ci.ppdev.mc.xerox.com/DTRLogs/Logs/AutoPrintReliability/UMEM/$hostname.umem.$time_stamp.before'>umem.before.txt</a></td> \n";
print MY_Header "</tr> \n";
print MY_Header "<tr> \n";
print MY_Header "<td align=left bgcolor=FFFF99> Memory Leakages after running Reliability test  </td> \n";
print MY_Header "<td align=left bgcolor=FFFF99><a href='http://ci.ppdev.mc.xerox.com/DTRLogs/Logs/AutoPrintReliability/UMEM/$hostname.umem.$time_stamp.after'>umem.after.txt</a></td> \n";
print MY_Header "</tr> \n";
print MY_Header "<tr> \n";
print MY_Header "<td align=left bgcolor=FFFF99> Memory Leakages Final Result  </td> \n";
print MY_Header "<td align=left bgcolor=FFFF99><a href='http://ci.ppdev.mc.xerox.com/DTRLogs/Logs/AutoPrintReliability/UMEM/$hostname.umem.$time_stamp.results'>umem.results.txt</a></td> \n";
print MY_Header "</tr> \n";
print MY_Header "</table>";
print MY_Header;
close(MY_Header);

}


########## print_help ##########
##
## Print Help Message
##
##########

sub print_help()
{
	print "*** umem.pl *** \n";
	print "usage: umem.pl -suite <name> -test <name> [-logdir <dir>] [-comp {ab am all}] [-before] [-after]\n";
	print " -h                     help \n";
	print " -before                dump file before test \n";
	print " -after                 dump file after test \n";
	print " -comp <ab> <am> <all>  compare files (after/before, after/master, after/before/master)\n";
	print " -suite <name>          suite name\n";
	print " -test <name>           test name\n";
	print " -binary <name(s)>      specific binaries to check.\n";
	print " -logdir <dir>          root log directory\n";
}



########## ProcessCommandLine ##########
## 
## Only one option right now.
## 
##########

sub ProcessCommandLine() {

	my $index = 0;
	
	foreach $option (@ARGV) {
		UMOPTIONS: {
			if ($option eq "-h")	    { print_help(); exit; last UMOPTIONS; }
			if ($option eq "-help")	    { print_help(); exit; last UMOPTIONS; }
			if ($option eq "-before")	{ $before = 1; last UMOPTIONS; }
			if ($option eq "-after")	{ $after = 1; last UMOPTIONS; }
			if ($option eq "-compare")	{ $compare = 1; $compwhat = $ARGV[$index + 1]; last UMOPTIONS; }
			if ($option eq "-binaries") { $binaries = $ARGV[$index + 1]; last UMOPTIONS;}
			if ($option eq "-logdir")   { $logdir = $ARGV[$index + 1]; last UMOPTIONS;}
			if ($option eq "-suite")   	{ $suite = $ARGV[$index + 1]; last UMOPTIONS;}
			if ($option eq "-test")     { $test = $ARGV[$index + 1]; last UMOPTIONS;}
		}
		
		$index++;	
	}
		
	if (($suite eq "") || ($test eq "")) {
		print("Suite and Test name must be specified.\n");
		print_help();
		exit;
	}
}

##############################################################
####################   MAIN ROUTINE    #######################
##############################################################
##
## Process command lines options one at a time
## If it matches and needs an argument the next command line option is used.
##
## Note, the arg after the option is looked at next time through the
## loop, but if it doesn't start with "-" it won't be flagged as an
## invalid option.
##
## Remember if you add a command line option here
## to declare/initialize it in the global variables
## If it is meant to override a configuration file variable
## make sure there is a check for it in read_config. 
## 
##########
ProcessCommandLine();
	
my $curpath = `pwd`;
chomp($curpath);
	
if ($logdir eq "") {
	$logdir = ReadCompareConfig($curpath,"LogDir");
	$logdir =~ s/^\s+//; 			# no leading white 
}
		
$logdir = "$logdir/$suite/$test";
	
if (!(-e "$logdir")) {
	system("mkdir -p $logdir");
		
	if (($? >> 8) != 0) {
		print("Could not make logdir: $logdir\n");
		print("logdir is now /tmp\n");
		$logdir = "/tmp";
	}
	else {
		system("chmod 777 $logdir");
	}
}

$hostname = `hostname`;
chomp($hostname);

if (($before == 1) || ($after == 1)) {
	CheckAndDumpUmemStats();
}
	
####################################################
###### Comparing the before and After UMEM logs ####
####################################################
if ($compare == 1) {

	CompareAvailableLogs($logdir);
			
	system("mv $logdir/$hostname.umem.after $logdir/$hostname.umem.$time_stamp.after");
	system("chmod 666 $logdir/$hostname.umem.$time_stamp.after");
	system("mv $logdir/$hostname.umem.before $logdir/$hostname.umem.$time_stamp.before");
	system("chmod 666 $logdir/$hostname.umem.$time_stamp.before");

}

####################################################################
############### Examples and tests #################################
####################################################################
### umem.pl -before -suite cimagerSuite -test cimagerTest        ###
### umem_main -after -suite cimagerSuite -test cimagerTest       ###
### umem_main -compare ab -suite cimagerSuite -test cimagerTest  ###
####################################################################
