#!/usr/bin/perl
#
use Fcntl;
use FindBin;
use File::Path;

use lib "$FindBin::Bin";

require "deleteall.pl";

########## HOW TO USE ##########
#
#	Used by Compare_job.pl.real & ART_Performance.pl
#
#   use require "PerfCompCommon.pl"; to include in file
#
################################

########## GOBALS ##########

umask(000);		## override user umask so we all can have access

my $EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";

##############################################################
# return codes                                               #
my $RETURN_SUCCESS    =    0;   # - All pages match          #
my $RETURN_NOMATCH    =    -1;  # - No pages match           #
my $RETURN_SOMEMATCH  =    -2;  # - Some pages match         #
my $RETURN_CONFIG_ERR =    -3;  # - config error             #
my $RETURN_IO_ERR     =    -4;  # - IO error   	             #
my $RETURN_UNKNOWN    =    -5;  # - Unknown error            #
my $RETURN_SAVED	  =    -6;  # - Master Files Saved	     #
my $RETURN_MDNOMATCH  =    -7;  # - Master Dir no match	     #
my $RETURN_NOSAVED	  =    -8;  # - Master Files Saved	     #
my $RETURN_JOBSNOTSAVING = -9;  # - Some Jobs not comp/saved #
##############################################################


##############################################################
######### Test Functions Used By External Testing ############
##############################################################
my $common_unitTest = 0;

########## ts_setCommonUnitTest ##########
##
## Sets Unit test variable.
##
##########

sub ts_setCommonUnitTest {
	$common_unitTest = 1;
}

##############################################################
#################### START SUBROUTINES #######################
##############################################################


########## writeAttributesToFile ##########
## 
## Log Attributes used for starting up compare
## to log file, before starting.  
## 
## Remember to modify this if add or delete attributes.
##########

sub writeAttributesToFile() {
	local($testInfoRef, $docuspInfoRef, $time) = @_;
			
	message("Compare Job started\n");
	message("Machine Stats\n");
	message("\tDocuSP System Mach:  $docuspInfoRef->{'system_mach'}\n");
	message("\tDocuSP IOT Type:     $docuspInfoRef->{'DocuSP_IOT_type'}\n");
	message("\tDocuSP BLD_VERSION:  $docuspInfoRef->{'bld'}\n");
	message("\tNumber of CPUs:      $docuspInfoRef->{'number_of_cpus'} \n");
	message("\tCPU Speed:           $docuspInfoRef->{'cpu_speed'}\n");	 
	message("\tRAM:                 $docuspInfoRef->{'memory_size'}\n");
	message("\tRIPS:                $docuspInfoRef->{'number_of_rips'}\n");
	
	message("Config file enteries:\n");
	message("\tMaster Location:     $testInfoRef->{'Master_Location'}\n");
	message("\tinput_Location:      $testInfoRef->{'input_Location'}\n");
	message("\toutput_Location:     $testInfoRef->{'output_Location'}\n");
	message("\tLogDir:              $testInfoRef->{'LogDir'}\n");
	message("\tCompareType:         $testInfoRef->{'CompareType'}\n");
	message("\tDelete_Files:        $testInfoRef->{'Delete_Files'}\n");
	message("\tSave_Files:          $testInfoRef->{'Save_Files'}\n");
	message("\tLogging_Off:         $testInfoRef->{'Logging_Off'}\n");
	message("\tCompare_XPIF:        $testInfoRef->{'Compare_XPIF'}\n");
	message("\tCompare_PSWrapper:   $testInfoRef->{'Compare_PSWrapper'}\n");
	message("\tSuite:               $testInfoRef->{'suite'}$testInfoRef->{'testname'}\n");
	message("\tJob:                 $testInfoRef->{'job'}\n");
	message("\tSaveDifDir:          $testInfoRef->{'Save_Difs_Dir'}\n");
	message("\tEmail_Address:       $testInfoRef->{'Email_Address'}\n");
	message("\tSave_New_Masters:    $testInfoRef->{'Save_New_Masters'}\n");
	message("\tSave_Masters_Dir:    $testInfoRef->{'Save_Masters_Dir'}\n");
	message("\tAccounting_On:       $testInfoRef->{'Accounting_On'}\n");
	message("\tHTML_Dir:            $testInfoRef->{'HTML_Dir'}\n");
	message("\t-----Tolerance Information---------------------------------\n");
	message("\tXM2Tolerance:        $testInfoRef->{'Tolerance'}\n");
	message("\tPerfTolerance:       $testInfoRef->{'PerformanceTolerance'}\n");
	message("\tNewMasterTolerance:  $testInfoRef->{'NewMasterTolerance'}\n");
	message("\t-----PPR Information---------------------------------------\n");
	message("\tPPR Testing:         $testInfoRef->{'PPRTest'}\n");
	message("\tNumber Of Rips:      $testInfoRef->{'NumberOfRips'}\n");
	message("\tGroup Testing: 	$testInfoRef->{'PerformanceGroupTest'}\n");
	message("\t-----Performance Information-------------------------------\n");
	message("\tAllstats:            $testInfoRef->{'Allstats'}\n");
	message("\tprstat:              $testInfoRef->{'prstat'}\n");
	message("\tvmstat:              $testInfoRef->{'vmstat'}\n");
	message("\tiostat:              $testInfoRef->{'iostat'}\n");
	message("\tmemstat:             $testInfoRef->{'memstat'}\n");
	message("\t-----Gateways and remote Information-----------------------\n");
	message("\tDisable rlogin:      $testInfoRef->{'Disable_rlogin'}\n");
	message("\tDisable Gateways:    $testInfoRef->{'Disable_Gateways'}\n");
	message("\tDisable Remote Gui:  $testInfoRef->{'Disable_RemoteGui'}\n");

	### generate_HTML will use these values to create the web page	
	logforhtml(1, "TimeStamp:$time\n");
	logforhtml(1, "MAIN:$docuspInfoRef->{'host_name'}:$docuspInfoRef->{'DocuSP_build_version'}:$docuspInfoRef->{'DocuSP_IOT_type'}:$docuspInfoRef->{'number_of_cpus'}:$docuspInfoRef->{'cpu_speed'}:$docuspInfoRef->{'memory_size'}:$docuspInfoRef->{'number_of_rips'}:$docuspInfoRef->{'system_mach'}:$testInfoRef->{'Compare_XPIF'}:$testInfoRef->{'Compare_PSWrapper'}\n");
	logforhtml(1, "Suite:$testInfoRef->{'suite'}$testInfoRef->{'testname'}\n");
	logforhtml(1, "Job:$testInfoRef->{'job'}\n");
	logforhtml(1, "SaveDifDir:$testInfoRef->{'Save_Files'}:$testInfoRef->{'Save_Difs_Dir'}\n");
	logforhtml(1, "HTMLDir:$testInfoRef->{'HTML_Dir'}\n");
	logforhtml(1, "LogDir:$testInfoRef->{'LogDir'}\n");
	logforhtml(1, "LogFile:$testInfoRef->{'LOG_FILE'}\n");
}


########## open_Log ##########
##
## Opens Log
##
##########

sub open_Log {
	local($logDir, $hostname, $bldver, $suite, $testname, $time_stamp, $createsubdirs) = @_;
	
	my $Logfile = "";
	my $resultsForHTML = "";
	
	if ( $createsubdirs ) {
		$logFileDir = "$logDir/$suite/$testname";
	}
	else {
		# if ($suite ne "") {
		# 	$logFileDir = "$logDir/$suite/rogueLogs";
		# }
		# else {
		# 	$logFileDir = "$logDir/rogueLogs";
		# }
		$logFileDir = "$logDir";
	}
	
	### Create log file directory if it doesn't exist.
	if ( !(-e $logFileDir) ) {
		mkpath([$logFileDir], 0, 0777)
			or die "Could not create log file directory: $logFileDir \n";
	}
	
	$Logfile = "$logFileDir/$hostname" . "_" . $time_stamp . "_" . $bldver . "_" . $suite . $testname . "_Compare.log";
	$resultsForHTML =  $Logfile . ".forhtml";
	
	print("\nopen_Log: Logfile = $Logfile\n");
	
	open( LOG, ">$Logfile")
		or die "Couldn't open Log file: $Logfile for writing. \n";
		
	open( FORHTML, ">$resultsForHTML")
		or die "Couldn't open file: $resultsForHTML for writing. \n";	
		
	open( FORHTMLB, ">$resultsForHTML.2")
		or die "Couldn't open file: $resultsForHTML.2 for writing. \n";	
				
	return($Logfile, $resultsForHTML);
}


########## close_Log ##########
##
## Closes Log
##
##########

sub close_Log() {
	close(LOG);
}


########## close_forHTMLFiles ##########
##
## Opens HMTL files
##
##########

sub close_forHTMLFiles {
	close(FORHTML);
	close(FORHTMLB);
}


########## message ##########
##
## Writes output to the debug log.  
## Output consists of date, time, and log message
##
##########

sub message {
	my ($my_message) = @_;

	my $currenttime = localtime;
	print(LOG "$currenttime\t$my_message");
}


########## logforhtml ##########
##
## Writes output to a file for generate_html to translate
## into a web page.  Translation occurs at end of Compare
##
##########

sub logforhtml {
	local($fileno, $my_message) = @_;
	
	if ($fileno == 1) {
		print FORHTML "$my_message";
	}	
	else {
		print FORHTMLB "$my_message";	
	}
}


########## read_config ##########
##
## Reads any config file, puts in a hash table and returns
## Assumes entries in config are like the following: Master_Location:/home/kahn/master_location
## Valid data sections of config file are shown 
## in the brackets after  $User_Preferences{"<Config Section>"}
## 
## Note: Input via Command line takes precedence over Config File Entries
##
##########

sub read_config {
	local($Configfile) = @_;
	
	my %configFileSettings = ();
	my $var;
	my $value;
	
	if (!(-e $Configfile)) {
		print("read_config: Could not find config file: $Configfile\n");
		print("read_config: Warning: Using default Config file on lafawnduh\n");
		$Configfile = "./config/Compare_Job.config";
	}
	
	print("\nread_config: Configfile = $Configfile\n");
	
	open(CONFIG, "<$Configfile")
		or die "Couldn't open Config file: $Configfile for reading. \n";

	while (<CONFIG>) { 
		chomp; 				# no newline
		s/#.*//; 			# no comments 
		s/^\s+//; 			# no leading white 
		s/\s+$//; 			# no trailing white 
		next unless length; 		# anything left?

		if(/:/){
			($var, $value) = split(/\s*:\s*/,$_, 2);	
		}
		else{
			($var, $value) = split(/\s*=\s*/,$_, 2);
		}
		chomp($var);
		chomp($value);
		$configFileSettings{$var} = $value;
   	}
   
	close(CONFIG);
	
	return(%configFileSettings);
}

########## write_config ##########
##
##	Takes a hash table and a file, and output the contents of the hash into the file
##	If the file aleady exists, it will try and merge the contents. 
##
##########

sub write_config {
	local($Configfile, %configFileSettings) = @_;
	
	print "trying to write config $Configfile\n";
		
	if (!(-e $Configfile)) {
		open(CONFIG, ">$Configfile") 
		or die "Couldn't open Config file: $Configfile for writing. \n";
		
		while ( ($key,$val) = each(%configFileSettings)){
			if( !( $key eq "" || $key eq undef )){
				if( $val eq "" || $val eq undef ){
					print(CONFIG "$key\n");
				}
				else{
					print(CONFIG "$key = $val\n");
				}
			}
		}	
	}
	else{
		%OldconfigFileSettings = read_config($Configfile);
	
		print "trying to merge config files\n";
		
		Merge_Hashes( \%configFileSettings,\%OldconfigFileSettings );
		
		open(CONFIG, ">$Configfile") 
		or die "Couldn't open Config file: $Configfile for writing. \n";

		while ( ($key,$val) = each(%configFileSettings)){
			if( !( $key eq "" || $key eq undef )){
			
				if( $val eq "" || $val eq undef ){
					print(CONFIG "$key\n");
				}
				else{
					print(CONFIG "$key = $val\n");
				}
			}
		}
	}
		
	close(CONFIG);	
}

########## Merge_Hashes ##########
##
##	takes two hashes table and combines their content, the first hash table
##	is given the higher priority
##
##########
sub Merge_Hashes {
	local($BetterTable, $LesserTable) = @_;
	
	#go through the lesser priority hash copy over any values not in the better hash
	while ( ($key,$val) = each(%{$LesserTable})){
			
			if( !( $key eq "" || $key eq undef )){			
				if( $BetterTable->{$key} eq "" || $BetterTable->{$key} eq undef ){
					$BetterTable->{$key} = $val;
				}
			}
	}
	
	#return %BetterTable;

}

########## ReconcilePreferences ##########
##
## Compares what's in the master location
## If not initialized uses the next best info it has.
## 
## Returns master filled with more data
## 
## Note: Input via Command line takes precedence over Config File Entries
##
##########
  
sub ReconcilePreferences {
 	local($master, $moreinfo) = @_;
	   
	if ( $master->{"Master_Location"} eq "" ) {
		$master->{"Master_Location"} = $moreinfo->{"Master_Location"};
	}
	if ( $master->{"input_Location"} eq "" ) {
		$master->{"input_Location"} = $moreinfo->{"input_Location"};
	}
	if ( $master->{"output_Location"} eq "" ) {
		$master->{"output_Location"} = $moreinfo->{"output_Location"};
	}
	if (  $master->{"LogDir"} eq "" ) {  
		$master->{"LogDir"} = $moreinfo->{"LogDir"};
	}
	if ( $master->{"CompareType"} eq "" ) {
		$master->{"CompareType"} = $moreinfo->{"CompareType"};
	}
	if (( $master->{"Delete_Files"} == -1 ) || ($master->{"Delete_Files"} eq "")) {
		$master->{"Delete_Files"} = $moreinfo->{"Delete_Files"};
	}
	if (( $master->{"Save_Files"} == -1 ) || ($master->{"Save_Files"} eq "")) {
		$master->{"Save_Files"} = $moreinfo->{"Save_Files"};
	}
	if (( $master->{"Logging_Off"} == -1 ) || ($master->{"Logging_Off"} eq "")) {
		$master->{"Logging_Off"} = $moreinfo->{"Logging_Off"};
	}
	if (( $master->{"Compare_XPIF"} == -1 ) || ($master->{"Compare_XPIF"} eq "")) {
		$master->{"Compare_XPIF"} = $moreinfo->{"Compare_XPIF"};
	}
	if ( $master->{"Email_Address"} eq "" ) { 
		$master->{"Email_Address"} = $moreinfo->{"Email_Address"};
	}
	if ( $master->{"Save_Difs_Dir"} eq "" ) { 
		$master->{"Save_Difs_Dir"} = $moreinfo->{"Save_Difs_Dir"};
	} 
	if (( $master->{"Accounting_On"} == -1 ) || ($master->{"Accounting_On"} eq "")) { 
		$master->{"Accounting_On"} = $moreinfo->{"Accounting_On"};
	}    
	if (( $master->{"Save_New_Masters"} == -1 ) || ($master->{"Save_New_Masters"} eq "")){ 
		$master->{"Save_New_Masters"} = $moreinfo->{"Save_New_Masters"};
	}    
	if ( $master->{"Save_Masters_Dir"} eq "" ) { 
		$master->{"Save_Masters_Dir"} = $moreinfo->{"Save_Masters_Dir"};
	}
	if ( $master->{"HTML_Dir"} eq "" ) {  
		$master->{"HTML_Dir"} = $moreinfo->{"HTML_Dir"};
	}
	if (( $master->{"Compare_PSWrapper"} == -1 ) || ($master->{"Compare_PSWrapper"} eq "")) {
		$master->{"Compare_PSWrapper"} = $moreinfo->{"Compare_PSWrapper"};
	}
	
	#result tolerances 
	if (( $master->{"Tolerance"} == -1 ) || ($master->{"Tolerance"} eq "")) { 
		$master->{"Tolerance"} = $moreinfo->{"Tolerance"};
	}
	if (( $master->{"PerformanceTolerance"} == -1 ) || ($master->{"PerformanceTolerance"} eq "")) { 
		$master->{"PerformanceTolerance"} = $moreinfo->{"PerformanceTolerance"};
	}
	if (( $master->{"NewMasterTolerance"} == -1 ) || ($master->{"NewMasterTolerance"} eq "")) { 
		$master->{"NewMasterTolerance"} = $moreinfo->{"NewMasterTolerance"};
	}
	
	#ppr settings
	if (( $master->{"PerformanceGroupTest"} == -1 ) || ($master->{"PerformanceGroupTest"} eq "")) { 
		$master->{"PerformanceGroupTest"} = $moreinfo->{"PerformanceGroupTest"};
	}
	if (( $master->{"PPRTest"} == -1 ) || ($master->{"PPRTest"} eq "")) { 
		$master->{"PPRTest"} = $moreinfo->{"PPRTest"};
	}
	if (( $master->{"NumberOfRips"} == -1 ) || ($master->{"NumberOfRips"} eq "")) { 
		$master->{"NumberOfRips"} = $moreinfo->{"NumberOfRips"};
	}
	
	#Performance information gathering
	if (( $master->{"Allstats"} == -1 ) || ($master->{"Allstats"} eq "")) {
		$master->{"Allstats"} = $moreinfo->{"Allstats"};
	}
	if (( $master->{"prstat"} == -1 ) || ($master->{"prstat"} eq "")) {
		$master->{"prstat"} = $moreinfo->{"prstat"};
	}
	if (( $master->{"vmstat"} == -1 ) || ($master->{"vmstat"} eq "")) {
		$master->{"vmstat"} = $moreinfo->{"vmstat"};
	}
	if (( $master->{"iostat"} == -1 ) || ($master->{"iostat"} eq "")) {
		$master->{"iostat"} = $moreinfo->{"iostat"};
	}
	if (( $master->{"memstat"} == -1 ) || ($master->{"memstat"} eq "")) {
		$master->{"memstat"} = $moreinfo->{"memstat"};
	}
	
	#Gateways and remote
	if (( $master->{"Disable_rlogin"} == -1 ) || ($master->{"Disable_rlogin"} eq "")) {
		$master->{"Disable_rlogin"} = $moreinfo->{"Disable_rlogin"};
	}
	if (( $master->{"Disable_Gateways"} == -1 ) || ($master->{"Disable_Gateways"} eq "")) {
		$master->{"Disable_Gateways"} = $moreinfo->{"Disable_Gateways"};
	}
	if (( $master->{"Disable_RemoteGui"} == -1 ) || ($master->{"Disable_RemoteGui"} eq "")) {
		$master->{"Disable_RemoteGui"} = $moreinfo->{"Disable_RemoteGui"};
	}
	
	# return(%master);
}


########## getDocuSPConfig ##########
##
## Get information about the system. 
## system_mach will be either i386 or sparc.
##
##########

sub getDocuSPMachineInfo()
{
	my %DocuspMachInfo = ();
	
	$DocuspMachInfo{"system_mach"} =`mach`;
	chomp($DocuspMachInfo{"system_mach"});

	$DocuspMachInfo{"host_name"} =`hostname`;
	chomp($DocuspMachInfo{"host_name"});

	$DocuspMachInfo{"DocuSP_IOT_type"} = `grep Identity: /opt/XRXnps/configuration/server.config | sed -e 's<Identity: <<'`;
	chomp($DocuspMachInfo{"DocuSP_IOT_type"});

	$DocuspMachInfo{"DocuSP_build_version"} =`grep BLD /var/sadm/pkg/XRXinstll/pkginfo | sed -e 's<BLD_VERSION=<<'`;
	chomp($DocuspMachInfo{"DocuSP_build_version"});

	if ($DocuspMachInfo{"DocuSP_build_version"} eq ''){
    	print "DocuSP Build Version Not Found.\n";
    	exit $RETURN_CONFIG_ERR;
	}

	$DocuspMachInfo{"bld"} = unpack("A5", $DocuspMachInfo{"DocuSP_build_version"});

	$DocuspMachInfo{"number_of_cpus"} = `/usr/sbin/psrinfo -v | grep "processor operates" | wc -l | tr -s ' ' ',' | cut -f2 -d,`;
	chomp($DocuspMachInfo{"number_of_cpus"});
	$DocuspMachInfo{"cpu_speed"} = `/usr/sbin/psrinfo -v | grep "processor operates" | head -1 | tr -s ' ' ',' | cut -f7 -d,`;
	chomp($DocuspMachInfo{"cpu_speed"});
	$DocuspMachInfo{"memory_size"} = `/common/bin/top | grep Memory | tr -s ' ' ',' | cut -f2 -d,`;
	chomp($DocuspMachInfo{"memory_size"});
	$DocuspMachInfo{"number_of_rips"} = `grep MaxRIPs: /opt/XRXnps/configuration/server.config | sed -e 's<MaxRIPs: <<'`;
	chomp($DocuspMachInfo{"number_of_rips"});

	if ($DocuspMachInfo{"number_of_rips"} eq '') {
		$DocuspMachInfo{"number_of_rips"} = 1;
	}
	
	return(%DocuspMachInfo);
}


########## Hold_All_Queues ###########
##
## Hold all jobs in all queues, this doesn't work
##
##########
sub Hold_All_Queues
{
 	local($queuepath, @queueArray) = @_;
	
	print( "holding all queues\n" );
	print( "queueArray = @queueArray\n");
	
	### For each queue, hold the jobs
	foreach $queue (@queueArray) {
		system( "$EXEC_ANY $queuepath $queue hold" );
	}
}

########## Release_All_Queues ###########
##
## Release all jobs in all queues
##
##########
sub Release_All_Queues
{
	local($queuepath, @queueArray) = @_;
	
	### For each queue, release the jobs
	foreach $queue (@queueArray) {
		if (!(($queue =~ /HOLD/) || ($queue =~ /hold/))) {
			print( "releasing $queue\n" );		
			system( "$EXEC_ANY $queuepath $queue release" );
		}
	}
}

########## ReleaseQueues ##########
##
## Just In case a problem happened in
## a preceding test where all the queues
## go held.  Happens when a person
## stops a test in the middle of a performance test.
##
##########

sub ReleaseQueuesJIC() {

	my @queueArray = get_queues();
	my $queuepath = pwhich('queue');

	Release_All_Queues($queuepath, @queueArray);
}


1;
