#!/usr/bin/perl

use Fcntl;
use FindBin;

use lib "$FindBin::Bin";

##############################################################
######################## GLOBALS ONLY ########################
##############################################################

########## TEST INFO LOCATIONS ##########

$root_of_logs = "/net/lafawnduh/export/home0/";
$citd_auto_logs = "/net/lafawnduh/export/home0/logs";
$citd_ruby_bin = "/net/lafawnduh/citd_auto/bin";
$AccountingDir = "/net/lafawnduh/opt/citd_auto/art_accounting";
$AccountingFile = "accounting.perf";


########## VARIOUS INFO ##########

$machineType = `mach`;
chomp($machineType);
$OS = `uname -s`;
chomp($OS);
$OSRev = `uname -r`;
chomp($OSRev);
$machineSpecificBinDir = "bin.$OS-$OSRev-$machineType";

########## FILE LOCATIONS ##########
$CITD_HOME = ".";
$CITD_CONFIG_DIR = "$CITD_HOME/config";
$CITD_HOME_PERL = "$CITD_HOME/perl";
$CITD_HOME_BIN = "$CITD_HOME/bin";
$CITD_TEST_REPO = "/net/lafawnduh/export/home/test_library/test_repo";
$CITD_MASTERS = "/net/lafawnduh/export/home/test_library/test_masters";
$CITD_DIFFS = "/common/ART_test_masters/diffs";
$CITD_LOGS = "/net/lafawnduh/export/home0/logs";
$CITD_LOGS_ROOT = "/net/lafawnduh/export/home0";
$CITD_LINKDIR = "http://pythias.ppdev.mc.xerox.com";
$CITD_TESTSCHEDULEDIR = "/net/lafawnduh/export/home0/tdd_scripts/tests";
$CITD_PERFTOOLS = "/performance/tools/$machineType" . "_tools";

$EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";
