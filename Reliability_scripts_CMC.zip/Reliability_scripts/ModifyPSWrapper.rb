#!/opt/csw/bin/ruby -W0 -S

# = Synopsis
#
#	If called from a command line:
#
#		* Takes the following Options:
#	
#
#


$:.unshift File.join(File.dirname(__FILE__))
$: << "/net/lafawnduh/opt/citd_auto/bin"

require 'ARTGlobals.rb'
require 'ConfigAccess.rb'
require 'MiscMethods.rb'

require 'optparse'
require 'pp'

include FileUtils::Verbose
include MiscMethods

File.umask(000)

##############################################################
########################### Globals ##########################
##############################################################



##############################################################
################### CLASS - ModifyPSWrapper ##################
##############################################################


class ModifyPSWrapper

					
=begin rdoc
	initialize
=end


	def initialize()

	end
	
	
=begin rdoc
	removeUMEM()
=end

	def removeUMEM()
		status = 0
	
		if File.exists?("/opt/XRXnps/log/extendedFile.log")
			filestrings = File.readlines("/opt/XRXnps/bin/ps_cdf").to_s
			
			newstring = filestrings.gsub!('LD_PRELOAD_32="/usr/lib/extendedFILE.so.1 libumem.so.1"',
							  "LD_PRELOAD_32=/usr/lib/extendedFILE.so.1")
			
			if newstring != nil
				system("#{$EXEC_ANY} /usr/bin/cp /opt/XRXnps/bin/ps_cdf /opt/XRXnps/bin/ps_cdf.withUMEM")
						
				newWrapper = File.open("/tmp/ps_cdf.noumem", File::CREAT|File::TRUNC|File::RDWR, 0777)
				newWrapper << newstring
				newWrapper.close()
			
				system("#{$EXEC_ANY} /usr/bin/cp /tmp/ps_cdf.noumem /opt/XRXnps/bin/ps_cdf")
				system("#{$EXEC_ANY} /usr/bin/rm /tmp/ps_cdf.noumem")
				status = 1
			end
		end	
		
		return(status)
		
	end

=begin rdoc
	addUMEM()
=end
	def addUMEM()
		status = 0
		
		if File.exists?("/opt/XRXnps/log/extendedFile.log")
			filestrings = File.readlines("/opt/XRXnps/bin/ps_cdf").to_s
			
			newstring = filestrings.gsub!("LD_PRELOAD_32=/usr/lib/extendedFILE.so.1", 
			                  			  'LD_PRELOAD_32="/usr/lib/extendedFILE.so.1 libumem.so.1"')
		
			if newstring != nil
				system("#{$EXEC_ANY} /usr/bin/cp /opt/XRXnps/bin/ps_cdf /opt/XRXnps/bin/ps_cdf.withoutUMEM")
						
				newWrapper = File.open("/tmp/ps_cdf.umem", File::CREAT|File::TRUNC|File::RDWR, 0777)
				newWrapper << newstring
				newWrapper.close()
			
				system("#{$EXEC_ANY} /usr/bin/cp /tmp/ps_cdf.umem /opt/XRXnps/bin/ps_cdf")
				system("#{$EXEC_ANY} /usr/bin/rm /tmp/ps_cdf.umem")
							
				status = 1
			end
		end
		
		return(status)
	end


end  ### Class ModifyPSWrapper


##############################################################
######################## START MAIN ##########################
##############################################################
# :main: ModifyPSWrapper.rb
#
#	takes a few command line options.
#	parses them and acts on them, returns the 
#	appropriate status.
#	
#		* Takes the following Options:
			
#
#		Usage: ruby ModifyPSWrapper.rb 	
#	

if __FILE__ == $0
	remove = false
	add = false
	status = 0
		
	opts = {}
	  
	ARGV.options do |opts|	
		opts.on("-r", "--remove") do remove = true end
		opts.on("-a", "--add") do add = true end
		opts.parse!
	end
		
	mw = ModifyPSWrapper.new()
	
	if add == true
		status = mw.addUMEM()
	elsif remove == true
		status = mw.removeUMEM()	
	end
	
	exit(status)
end
