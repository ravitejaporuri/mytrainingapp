#!/usr/bin/perl
#

use Fcntl;
use FindBin;

use lib "$FindBin::Bin";

########## GLOBALS ##########

my $machineType = `mach`;
chomp($machineType);
my $OS = `uname -s`;
chomp($OS);

my $host = `hostname`;
chomp($host);

my $IOT = `grep 'Family:' /opt/XRXnps/configuration/server.config | sed 's/Family: //' | sed -n 1p`;
chomp($IOT);

my $OSRev = `uname -r`;
chomp($OSRev);

my $machineSpecificBinDir = "bin.$OS-$OSRev-$machineType";
### print("my machinedir: $machineSpecificBinDir\n");
my $tmpList = "";
my @tmpArray = ();
my $EXEC_ANY = "/opt/XRXnps/autoTest/bin/execAny";


##############################################################
#################### START SUBROUTINES #######################
##############################################################


########## Changes the permissions of tmp directory ##########
## 
## Gives full permissions to the folder /tmp directory
## 
##########

sub ChangePerm() {
	my $tmpDir= "/tmp/" . $host . "_reliab" . "/REL_" . $IOT;

	if (!(opendir(TMPDIR, $tmpDir ))) {
		print("InputFile Dir, $tmpDir, Problem\n");
		return(-1);
	}
		
	my @files = grep((!/^\.\.?$/ ), readdir(TMPDIR));
	
	closedir(TMPDIR);
		
	system("$EXEC_ANY /bin/chmod -R 777 \"$tmpDir\"");
	
}

##############################################################
######################## START MAIN ##########################
##############################################################

ChangePerm();
